import re,struct,sys,collections
so=open('/home/claude/work/apk/lib/armeabi/libgame.so','rb').read()
def foff(v): return v if v<0x371b10 else v-0x1000
def word(v):
    o=foff(v); return struct.unpack('<I',so[o:o+4])[0] if 0<=o<len(so)-3 else None
# relocs
rel={}
for l in open('relocs.txt'):
    p=l.split()
    if len(p)>=4 and re.match(r'^[0-9a-f]{8}$',p[0]):
        rel[int(p[0],16)]=(p[2],p[4] if len(p)>4 else None)
def cstr(v):
    o=foff(v)
    if not(0<=o<len(so)): return None
    e=so.find(b'\0',o)
    s=so[o:e]
    if 1<=len(s)<80 and all(32<=c<127 or c in(9,10) for c in s): return s.decode()
def fl(w):
    f=struct.unpack('<f',struct.pack('<I',w))[0]
    return f
lines=open('/home/claude/work/anal/analisis-original/so_analysis/disassembly_arm32.txt').read().split('\n')
idx={}
for i,l in enumerate(lines):
    m=re.match(r'^([0-9a-f]{8}) <(.+)>:$',l)
    if m: idx[m.group(2)]=i
order=sorted(idx.items(),key=lambda x:x[1])
nxt={n:(order[k+1][1] if k+1<len(order) else len(lines)) for k,(n,i) in enumerate(order)}
def analyze(name):
    out=[];regs={}
    for l in lines[idx[name]+1:nxt[name]]:
        m=re.match(r'\s+([0-9a-f]+):\s+[0-9a-f]{8}\s+\t(\w+)\t?(.*)',l)
        if not m: continue
        a,op,args=m.groups();a=int(a,16)
        c=re.match(r'r(\d+), \[pc, #0x[0-9a-f]+\]\s+@ 0x([0-9a-f]+)',args) if op=='ldr' else None
        if c:
            w=word(int(c.group(2),16)); regs[c.group(1)]=('lit',w,len(out))
            out.append(('k',hex(w) if w is not None else None, round(fl(w),5) if w is not None else None, w))
            continue
        c=re.match(r'r(\d+), pc, r(\d+)',args) if op=='add' else None
        if c and regs.get(c.group(2),('',))[0]=='lit':
            li=regs[c.group(2)]; v=a+8+li[1]
            out[li[2]]=('x',)
            regs[c.group(1)]=('addr',v&0xffffffff)
            s=cstr(v&0xffffffff)
            if s is not None: out.append(('str',s))
            continue
        c=re.match(r'r(\d+), \[r(\d+), r(\d+)\]',args) if op=='ldr' else None
        if c and regs.get(c.group(2),('',))[0]=='addr' and regs.get(c.group(3),('',))[0]=='lit':
            slot=(regs[c.group(2)][1]+regs[c.group(3)][1])&0xffffffff
            out[regs[c.group(3)][2]]=('x',)
            regs.pop(c.group(1),None)
            r=rel.get(slot)
            if r and r[1]: out.append(('sym',r[1]))
            else:
                w=word(slot)
                s=cstr(w) if w else None
                if s is not None: out.append(('str',s))
                elif w is not None: out.append(('data',hex(w),w and round(fl(w),5)))
            continue
        if op=='bl' or op=='blx':
            t=re.search(r'<([^>+]+)',args)
            if t: out.append(('call',t.group(1)))
    return out
if __name__=='__main__':
    for n in sys.argv[1:]:
        print('##',n)
        seen=[]
        for o in analyze(n):
            if o==('x',): continue
            if o[0]=='k':
                w=o[3]
                if w is None: continue
                f=o[2]
                if not(w<0x1000 or (abs(f)>1e-4 and abs(f)<1e6 and w>0x1000000)): continue
                o=('const',o[1],f if w>0x1000000 else w)
            if o[0]!='call' and o in seen: continue
            if o[0]=='call' and (o[1].startswith(('_ZSt','__aeabi','__extend','__divsf','__mulsf','__addsf','__subsf','__floatsi')) ): continue
            seen.append(o)
        print('  '+'\n  '.join(' '.join(map(str,o)) for o in seen))
