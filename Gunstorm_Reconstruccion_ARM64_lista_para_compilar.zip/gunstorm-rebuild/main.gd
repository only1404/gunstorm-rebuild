extends Control

# Reconstrucción jugable inicial basada en los recursos gráficos recuperados.
# No es el código original de Gunstorm; es una implementación nueva.

const ENEMY_FILES := [
    "res://assets/sprites/enemy/EnemyA-Aimed.png.png",
    "res://assets/sprites/enemy/EnemyB-Aimed.png.png",
    "res://assets/sprites/enemy/EnemyC-Aimed.png.png"
]
const ENEMY_DEAD_FILES := [
    "res://assets/sprites/enemy/EnemyA-Dead.png.png",
    "res://assets/sprites/enemy/EnemyB-Dead.png.png",
    "res://assets/sprites/enemy/EnemyC-Dead.png.png"
]
const GAME_W := 720.0
const GAME_H := 1280.0

var mode := "menu"
var score := 0
var lives := 3
var spawn_clock := 0.0
var spawn_delay := 1.25
var enemies: Array[Dictionary] = []
var shots: Array[Dictionary] = []
var score_label: Label
var lives_label: Label
var message_label: Label
var start_button: Button
var menu_layer: Control
var gameover_layer: Control
var rng := RandomNumberGenerator.new()

func _ready() -> void:
    rng.randomize()
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_STOP
    _build_hud()
    _show_menu()

func _build_hud() -> void:
    var background := ColorRect.new()
    background.color = Color("#151923")
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    background.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(background)
    move_child(background, 0)

    var header := ColorRect.new()
    header.color = Color("#252b38")
    header.position = Vector2.ZERO
    header.size = Vector2(GAME_W, 112)
    header.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(header)

    score_label = Label.new()
    score_label.position = Vector2(28, 24)
    score_label.size = Vector2(300, 64)
    score_label.text = "PUNTOS  0"
    score_label.add_theme_font_size_override("font_size", 32)
    add_child(score_label)

    lives_label = Label.new()
    lives_label.position = Vector2(430, 24)
    lives_label.size = Vector2(260, 64)
    lives_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    lives_label.text = "VIDAS  ♥ ♥ ♥"
    lives_label.add_theme_font_size_override("font_size", 30)
    add_child(lives_label)

    message_label = Label.new()
    message_label.position = Vector2(25, 1140)
    message_label.size = Vector2(670, 70)
    message_label.text = "TOCA A LOS ENEMIGOS PARA DISPARAR"
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 22)
    message_label.add_theme_color_override("font_color", Color("#e0e4ec"))
    add_child(message_label)

func _show_menu() -> void:
    mode = "menu"
    _clear_layer(menu_layer)
    menu_layer = Control.new()
    menu_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(menu_layer)

    var title := Label.new()
    title.text = "GUNSTORM"
    title.position = Vector2(30, 300)
    title.size = Vector2(660, 110)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 66)
    title.add_theme_color_override("font_color", Color("#f3f3f3"))
    menu_layer.add_child(title)

    var subtitle := Label.new()
    subtitle.text = "RECONSTRUCCIÓN JUGABLE"
    subtitle.position = Vector2(40, 405)
    subtitle.size = Vector2(640, 50)
    subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    subtitle.add_theme_font_size_override("font_size", 24)
    subtitle.add_theme_color_override("font_color", Color("#e6b45c"))
    menu_layer.add_child(subtitle)

    var instructions := Label.new()
    instructions.text = "Apunta con el dedo y toca a los enemigos.\nNo dejes que lleguen al final de la pantalla."
    instructions.position = Vector2(50, 510)
    instructions.size = Vector2(620, 110)
    instructions.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    instructions.add_theme_font_size_override("font_size", 25)
    instructions.add_theme_color_override("font_color", Color("#c9ced8"))
    menu_layer.add_child(instructions)

    start_button = Button.new()
    start_button.text = "JUGAR"
    start_button.position = Vector2(190, 690)
    start_button.size = Vector2(340, 100)
    start_button.add_theme_font_size_override("font_size", 38)
    start_button.pressed.connect(_start_game)
    menu_layer.add_child(start_button)

func _start_game() -> void:
    _clear_layer(menu_layer)
    menu_layer = null
    _clear_layer(gameover_layer)
    gameover_layer = null
    for e in enemies:
        if is_instance_valid(e.node): e.node.queue_free()
    enemies.clear()
    shots.clear()
    score = 0
    lives = 3
    spawn_clock = 0.0
    spawn_delay = 1.25
    mode = "playing"
    _update_hud()
    message_label.text = "TOCA A LOS ENEMIGOS PARA DISPARAR"

func _process(delta: float) -> void:
    if mode != "playing":
        return
    spawn_clock += delta
    if spawn_clock >= spawn_delay:
        spawn_clock = 0.0
        _spawn_enemy()
        spawn_delay = maxf(0.48, 1.25 - float(score) * 0.006)

    var escaped: Array[int] = []
    for i in range(enemies.size()):
        var e: Dictionary = enemies[i]
        var node: TextureRect = e.node
        if not is_instance_valid(node):
            escaped.append(i)
            continue
        var p: Vector2 = node.position
        p.y += float(e.speed) * delta
        node.position = p
        if p.y > 1060.0:
            node.queue_free()
            escaped.append(i)
            lives -= 1
            _update_hud()
    for i in range(escaped.size() - 1, -1, -1):
        enemies.remove_at(escaped[i])
    if lives <= 0:
        _show_game_over()

func _spawn_enemy() -> void:
    var idx := rng.randi_range(0, ENEMY_FILES.size() - 1)
    var texture := load(ENEMY_FILES[idx]) as Texture2D
    if texture == null:
        return
    var enemy := TextureRect.new()
    enemy.texture = texture
    enemy.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    enemy.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    enemy.size = Vector2(170, 170)
    enemy.position = Vector2(rng.randf_range(12, GAME_W - 182), rng.randf_range(135, 260))
    enemy.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(enemy)
    enemies.append({"node": enemy, "type": idx, "speed": rng.randf_range(105, 175) + score * 0.7})

func _input(event: InputEvent) -> void:
    if mode != "playing":
        return
    var point := Vector2.ZERO
    var is_shot := false
    if event is InputEventScreenTouch and event.pressed:
        point = event.position
        is_shot = true
    elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        point = event.position
        is_shot = true
    if not is_shot:
        return
    # El objetivo se considera acertado si se toca su rectángulo visible.
    for i in range(enemies.size() - 1, -1, -1):
        var e: Dictionary = enemies[i]
        var node: TextureRect = e.node
        if is_instance_valid(node) and node.get_global_rect().has_point(point):
            var dead_texture := load(ENEMY_DEAD_FILES[int(e.type)]) as Texture2D
            if dead_texture != null:
                node.texture = dead_texture
            node.queue_free()
            enemies.remove_at(i)
            score += 10
            _update_hud()
            message_label.text = "¡ACIERTO! +10"
            return
    message_label.text = "FALLO..."

func _update_hud() -> void:
    score_label.text = "PUNTOS  %d" % score
    var hearts := ""
    for i in range(lives): hearts += "♥ "
    lives_label.text = "VIDAS  " + hearts.strip_edges()

func _show_game_over() -> void:
    mode = "gameover"
    gameover_layer = Control.new()
    gameover_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var shade := ColorRect.new()
    shade.color = Color(0.02, 0.03, 0.05, 0.88)
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    gameover_layer.add_child(shade)
    add_child(gameover_layer)

    var title := Label.new()
    title.text = "FIN DE LA PARTIDA"
    title.position = Vector2(35, 390)
    title.size = Vector2(650, 90)
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 43)
    gameover_layer.add_child(title)

    var result := Label.new()
    result.text = "Puntuación: %d" % score
    result.position = Vector2(40, 495)
    result.size = Vector2(640, 70)
    result.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    result.add_theme_font_size_override("font_size", 34)
    gameover_layer.add_child(result)

    var again := Button.new()
    again.text = "VOLVER A JUGAR"
    again.position = Vector2(150, 625)
    again.size = Vector2(420, 90)
    again.add_theme_font_size_override("font_size", 30)
    again.pressed.connect(_start_game)
    gameover_layer.add_child(again)

func _clear_layer(layer: Control) -> void:
    if is_instance_valid(layer):
        layer.queue_free()
