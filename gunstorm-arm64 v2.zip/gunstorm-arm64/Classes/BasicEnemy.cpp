#include "BasicEnemy.h"
#include "GameplayScene.h"
#include <stdio.h>
using namespace cocos2d;

BasicEnemy* BasicEnemy::createWithSpriteFrameName(const char* raisedFrame, int spot) {
    BasicEnemy* e = new BasicEnemy();
    if (e && e->initWithSpriteFrameName(raisedFrame)) {
        std::string n = raisedFrame;
        e->baseName = n.substr(0, n.find('-'));            // "EnemyA"
        e->kind = e->baseName.empty() ? 'A' : e->baseName[e->baseName.size() - 1];
        e->spot = spot;
        e->state = IDLE;
        e->stateTime = 0;
        e->attackDelay = 0.5f;
        e->raisedDuration = 1.0f;
        e->reactionTime = 0;
        e->scene = NULL;
        e->blood = e->bloodHeadless = NULL;
        CCLog("m_pName is %s", e->baseName.c_str());
        e->autorelease();
        return e;
    }
    delete e;
    return NULL;
}

void BasicEnemy::initiate(CCNode* parent) {
    setAnchorPoint(ccp(0.5f, 0.0f));
    parent->addChild(this, 5);
    char plist[40];
    sprintf(plist, "blood_%c.plist", kind);
    blood = CCParticleSystemQuad::create(plist);
    sprintf(plist, "blood_%c_headless.plist", kind);
    bloodHeadless = CCParticleSystemQuad::create(plist);
    if (blood)         { blood->stopSystem();         parent->addChild(blood, 6); }
    if (bloodHeadless) { bloodHeadless->stopSystem(); parent->addChild(bloodHeadless, 6); }
    reset();
}

void BasicEnemy::reset() {
    stopAllActions();
    state = IDLE;
    stateTime = 0;
    setVisible(false);
    setOpacity(255);
    CCSpriteFrame* f = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName((baseName + "-Raised.png").c_str());
    if (f) setDisplayFrame(f);
}

void BasicEnemy::spawnIn() {
    stopAllActions();
    setVisible(true);
    setOpacity(255);
    state = RAISED;
    stateTime = 0;
    // APPROXIMATED motion: slides up from below its spot (original uses a CCMoveTo)
    setPosition(ccp(home.x, home.y - 120.0f));
    runAction(CCMoveTo::create(0.15f, home));
    CCSpriteFrame* f = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName((baseName + "-Raised.png").c_str());
    if (f) setDisplayFrame(f);
}

void BasicEnemy::update() {
    // The original multiplies by the director's animation interval (frame counting);
    // here we use the same interval so behaviour is frame-rate independent.
    float dt = (float)CCDirector::sharedDirector()->getAnimationInterval();
    if (state == RAISED) {
        stateTime += dt;
        if (stateTime >= raisedDuration) {
            state = AIMED;
            stateTime = 0;
            CCSpriteFrame* f = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName((baseName + "-Aimed.png").c_str());
            if (f) setDisplayFrame(f);
        }
    } else if (state == AIMED) {
        stateTime += dt;
        if (stateTime >= attackDelay) {
            state = SHOOTING;
            CCAnimation* a = CCAnimation::create();
            for (int i = 0; i <= 6; ++i) {
                char n[48];
                sprintf(n, "%s-Shoot%02d.png", baseName.c_str(), i);
                CCSpriteFrame* f = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(n);
                if (f) a->addSpriteFrame(f);
            }
            a->setDelayPerUnit(0.05f);   // APPROXIMATED
            runAction(CCSequence::create(CCAnimate::create(a),
                      CCCallFunc::create(this, callfunc_selector(BasicEnemy::onShotFinished)), NULL));
        }
    }
}

void BasicEnemy::onShotFinished() {
    if (scene) scene->onEnemyShotPlayer(this);
}

bool BasicEnemy::hasBeenHit() {
    if (state == AIMED) {
        reactionTime = calculateReactionTime();
        return true;
    }
    return false;
}

float BasicEnemy::calculateReactionTime() { return stateTime; }

void BasicEnemy::killEnemy(bool headshot) {
    stopAllActions();
    state = DEAD;
    CCSpriteFrame* f = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(
        (baseName + (headshot ? "-Headless.png" : "-Dead.png")).c_str());
    if (f) setDisplayFrame(f);
    CCParticleSystemQuad* p = headshot ? bloodHeadless : blood;
    if (p) { p->setPosition(ccp(getPositionX(), getPositionY() + getContentSize().height * 0.6f)); p->resetSystem(); }
    runAction(CCSequence::create(CCFadeTo::create(0.3f, 0),
              CCCallFunc::create(this, callfunc_selector(BasicEnemy::finishReset)), NULL));
}

void BasicEnemy::finishReset() { reset(); }

void BasicEnemy::escape() {
    stopAllActions();
    state = ESCAPING;
    runAction(CCSequence::create(CCMoveTo::create(0.2f, ccp(getPositionX(), home.y - 200.0f)),
              CCCallFunc::create(this, callfunc_selector(BasicEnemy::finishReset)), NULL));
}

void BasicEnemy::gameoverFade() {
    stopAllActions();
    runAction(CCFadeTo::create(0.5f, 90));
}
