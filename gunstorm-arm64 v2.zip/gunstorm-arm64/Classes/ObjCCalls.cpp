#include "ObjCCalls.h"
#include "cocos2d.h"
using namespace cocos2d;

void ObjCCalls::OpenURL(const char* url)                       { CCLog("ObjCCalls::OpenURL stub: %s", url ? url : ""); }
void ObjCCalls::reportAchievement(std::string id, int percent) { CCLog("ObjCCalls::reportAchievement stub: %s %d", id.c_str(), percent); }
void ObjCCalls::downloadPlayerScore(std::string, bool)         {}
int  ObjCCalls::getLoadedRank()                                { return -1; }
void ObjCCalls::reportScore(int score, const char*)            { CCLog("ObjCCalls::reportScore stub: %d", score); }
void ObjCCalls::alertviewQuitting()                            {}
bool ObjCCalls::chartboostHasCachedInterstitial(std::string)   { return false; }
void ObjCCalls::chartboostShowInterstitial(std::string)        {}
void ObjCCalls::chartboostCacheInterstitial(std::string)       {}
void ObjCCalls::setAtGameplayScene(bool)                       {}
void ObjCCalls::launchLeaderboards()                           {}
