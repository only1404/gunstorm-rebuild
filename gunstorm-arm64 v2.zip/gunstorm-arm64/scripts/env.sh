#!/usr/bin/env bash
# Shared settings. Versions chosen (all pinned):
#   NDK r17c  : last NDK that ships gnustl + gcc/clang for a 2013-era codebase AND supports arm64-v8a
#   CMake 3.10.2 (Android SDK package "cmake;3.10.2.4988404"): the CMake paired with r17c-era toolchains
#   JDK 17, Gradle 8.4, Android Gradle Plugin 8.1.4, compileSdk/targetSdk 34, minSdk 21
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export ROOT
export TP="$ROOT/third_party"
export COCOS2DX_ROOT="$TP/cocos2d-x"
export OVERRIDES="$TP/overrides"
export NDK_VERSION="r17c"
export ANDROID_NDK_HOME="${ANDROID_NDK_HOME:-$HOME/android-ndk-$NDK_VERSION}"
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Android/Sdk}}"
export CMAKE_BIN="${CMAKE_BIN:-$ANDROID_SDK_ROOT/cmake/3.10.2.4988404/bin/cmake}"
export NINJA_BIN="${NINJA_BIN:-$ANDROID_SDK_ROOT/cmake/3.10.2.4988404/bin/ninja}"
