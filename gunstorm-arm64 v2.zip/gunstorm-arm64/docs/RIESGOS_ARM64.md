# Riesgos de compilación y ejecución (no confirmados: nadie ha compilado esto aún)

Estas son zonas donde un código de 2013 suele fallar en arm64. **No son errores encontrados**; son lo que
hay que mirar si el log de Actions falla.

1. **Descarga del motor**: `fetch_deps.sh` busca una etiqueta git `…2.1.5` en `cocos2d/cocos2d-x`; si no existe,
   prueba `cocos2d-x.org/filedown/cocos2d-x-2.1.5.zip`. No he podido comprobar ninguna de las dos desde aquí.
2. **Módulos precompilados**: el motor trae libpng/libjpeg/libtiff/… solo para armeabi/armeabi-v7a/x86.
   `build_thirdparty.sh` genera módulos «override» a partir de los nombres que encuentre en
   `cocos2dx/platform/third_party/android/prebuilt/*/Android.mk`. Si el diseño del motor difiere, habrá que ajustarlo.
3. **Cabeceras vs. bibliotecas**: libpng 1.2.46 coincide con lo que usaba el juego; libjpeg-turbo 2.1.5.1 se compila con
   ABI 6.2 (por defecto) para ser compatible con cabeceras tipo libjpeg 6b. Si el motor trae sus propias cabeceras
   jpeg/tiff, pueden chocar.
4. **Código del motor con suposiciones de 32 bits** (a revisar en el log): conversiones puntero↔entero de 32 bits,
   `long`/`unsigned long` en estructuras de ZipUtils/CCZ y en llamadas a zlib, `va_list` con estructura en arm64,
   punteros a miembros, `CCObject` ↔ `unsigned int`.
5. **Java del motor** (`Cocos2dxActivity`, etc.) compila con compileSdk 34, pero usa API antiguas
   (`Cocos2dxHelper`, `Cocos2dxMusic`, `Cocos2dxBitmap`): pueden aparecer avisos o errores.
6. **Audio**: CocosDenshion/OpenSL de 2.1.5 carga `libOpenSLES` por `dlopen` y lee los `.ogg` de los assets; no probado.
7. **`CCLabelTTF`** usa `Cocos2dxBitmap` por JNI: no probado en Android moderno.
8. **Resolución**: `setDesignResolutionSize(1080·aspecto, 1080)` en pantallas 19.5:9; el original no usaba resolución de diseño.
9. **16 KB de página**: no aplica al S24 Ultra (4 KB), pero r17c no genera librerías alineadas a 16 KB.
