GUNSTORM REBUILT — PROTOTIPO JUGABLE 0.2

Esta es una reconstrucción nueva y experimental, no el código original del juego. Incluye una primera mecánica jugable: pantalla de inicio, enemigos que avanzan, disparo táctil al tocarlos, puntuación, vidas y fin de partida. Usa sprites recuperados del paquete de recursos.

IMPORTANTE: no se ha podido ejecutar Godot en este entorno, por lo que el proyecto y la exportación aún deben validarse. No es un APK listo ni probado todavía. La lógica, el ritmo, la escala y las animaciones no garantizan fidelidad completa al original. El código nativo original no estaba disponible.

COMPILAR APK ARM64 DESDE GITHUB (usando el teléfono):
1. Crea un repositorio nuevo en GitHub.
2. Sube todo el contenido de esta carpeta, incluida la carpeta oculta .github/workflows.
3. En GitHub abre Actions y ejecuta “Build Gunstorm Android ARM64 APK”. También se inicia al subir cambios a main/master.
4. Si la compilación termina correctamente, abre la ejecución y descarga el artefacto “Gunstorm-Rebuilt-Android-ARM64”. Dentro está el APK de depuración.

La acción depende de la disponibilidad y compatibilidad de la imagen Godot CI, Android SDK y plantillas de exportación. Si falla, hay que revisar el log de GitHub Actions y corregir la causa; no se debe asumir que la compilación fue exitosa.

CONFIGURACIÓN: Godot 4.x, orientación vertical, renderizador GL Compatibility, Android ARM64 solamente. Paquete: com.rebuild.gunstorm.

SEGURIDAD: no se incluye api_key.txt ni claves privadas.
