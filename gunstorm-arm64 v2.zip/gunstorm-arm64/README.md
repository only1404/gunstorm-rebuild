# GunStorm 1.0.3 — reconstrucción ARM64 (Cocos2d-x 2.1.5 + clases C++ reconstruidas)

> **Estado honesto:** este proyecto **no se ha compilado ni probado todavía**. Se preparó en un entorno
> sin NDK, sin Gradle y sin internet. El primer paso es ejecutar GitHub Actions y corregir los errores
> reales que aparezcan en los logs. Nada aquí está verificado en un dispositivo.
>
> **No es el código original recuperado.** El motor es el original (Cocos2d-x 2.1.5, el mismo que usaba el
> juego), pero las clases del juego (`GameplayScene`, `BasicEnemy`, …) están **reescritas** a partir de
> ingeniería inversa del binario ARM32 y de los recursos. Ver `docs/RECONSTRUCCION.md`.

## Qué contiene
- `Classes/` – clases del juego reconstruidas (C++).
- `jni/` – `Android.mk`, `Application.mk`, `main.cpp` (JNI de Cocos2d-x).
- `app/` – proyecto Gradle (Java `GunStormActivity` + recursos originales en `assets/`).
- `scripts/` – descarga de dependencias, compilación nativa, APK y verificación.
- `.github/workflows/build-apk.yml` – compilación automática y APK como artefacto.
- `docs/` – evidencia (tablas de oleadas decodificadas, símbolos resueltos), estado y riesgos.

## Versiones elegidas
| Herramienta | Versión | Motivo |
|---|---|---|
| Cocos2d-x | 2.1.5 (MIT) | la que usa el juego original (rutas de compilación dentro del `.so`) |
| NDK | r17c | último con `gnustl` y soporte arm64; el código es de 2013 |
| CMake (SDK) | 3.10.2 | pareja de toolchains de la era r17 (solo para libjpeg/libtiff) |
| libpng | 1.2.46 | la versión incluida en el binario original; coincide con las cabeceras del motor |
| JDK / Gradle / AGP | 17 / 8.4 / 8.1.4 | combinación soportada |
| compileSdk / targetSdk / minSdk | 34 / 34 / 21 | Android 14+ bloquea instalar apps con targetSdk < 23 |

## Compilar con GitHub Actions (recomendado)
1. Crea un repositorio **privado** (el ZIP incluye los recursos originales de Dobsoft Studios).
2. Sube el contenido de la carpeta (no el ZIP). Si usas el repo `only1404/gunstorm-rebuild`, haz una rama nueva.
3. Pestaña **Actions → Build GunStorm ARM64 APK → Run workflow** (o haz *push*).
4. Al terminar, descarga el artefacto **GunStorm-arm64-debug-apk**. Si falla, descarga **build-logs** y
   pásame los logs: ahí están los errores reales del motor en arm64.
5. En el móvil: permite instalar apps desconocidas e instala `app-debug.apk` (firma de depuración).

## Compilar en local (Linux)
```bash
# requisitos: JDK 17, Gradle 8.4, Android SDK (platform 34, build-tools 34.0.0, cmake;3.10.2.4988404), NDK r17c
export ANDROID_SDK_ROOT=...   ; export ANDROID_NDK_HOME=.../android-ndk-r17c
scripts/build_apk.sh          # fetch_deps -> build_thirdparty -> build_native -> gradle assembleDebug
scripts/verify_apk.sh         # firma, libgame.so arm64, assets (comprobación estática)
```

## Si la compilación falla
Pon los arreglos del motor como parches en `patches/*.patch` (formato `diff -u`, `-p1` sobre
`third_party/cocos2d-x`); `scripts/fetch_deps.sh` los aplica automáticamente. Lista de zonas de riesgo
conocidas en `docs/RIESGOS_ARM64.md`.

## Lo que NO hace (todavía)
Animaciones Spine (logo/botones), medallas, ranking/logros, anuncios y redes sociales (eliminados a propósito),
fondo original, valores exactos de puntuación/dificultad. Detalle en `docs/RECONSTRUCCION.md`.
