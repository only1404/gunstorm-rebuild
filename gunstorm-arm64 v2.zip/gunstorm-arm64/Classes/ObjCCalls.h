// Reconstructed from the symbol table of the original libgame.so (class ObjCCalls, JNI bridge).
// STATUS: stubs. The original called into Java for Chartboost, Facebook, Amazon GameCircle /
// Google Play Games. Those SDKs are intentionally removed in this build.
#ifndef __OBJCCALLS_H__
#define __OBJCCALLS_H__
#include <string>

class ObjCCalls {
public:
    static void OpenURL(const char* url);
    static void reportAchievement(std::string id, int percent);
    static void downloadPlayerScore(std::string board, bool force);
    static int  getLoadedRank();                 // -1 => offline / unknown
    static void reportScore(int score, const char* board);
    static void alertviewQuitting();
    static bool chartboostHasCachedInterstitial(std::string location);
    static void chartboostShowInterstitial(std::string location);
    static void chartboostCacheInterstitial(std::string location);
    static void setAtGameplayScene(bool atGameplay);
    static void launchLeaderboards();
};
#endif
