#!/usr/bin/env bash
# Builds libgame.so (arm64-v8a) with ndk-build and copies it where Gradle packages it.
set -euo pipefail
source "$(dirname "$0")/env.sh"
export NDK_MODULE_PATH="$OVERRIDES:$COCOS2DX_ROOT:$COCOS2DX_ROOT/cocos2dx/platform/third_party/android/prebuilt"
"$ANDROID_NDK_HOME/ndk-build" -C "$ROOT" -j"$(nproc 2>/dev/null || echo 4)" \
    NDK_PROJECT_PATH="$ROOT" NDK_APPLICATION_MK="$ROOT/jni/Application.mk" \
    APP_BUILD_SCRIPT="$ROOT/jni/Android.mk" NDK_OUT="$ROOT/build/obj" NDK_LIBS_OUT="$ROOT/build/libs" \
    COCOS2DX_ROOT="$COCOS2DX_ROOT" OVERRIDES="$OVERRIDES" V=0
mkdir -p "$ROOT/app/src/main/jniLibs/arm64-v8a"
cp "$ROOT/build/libs/arm64-v8a/libgame.so" "$ROOT/app/src/main/jniLibs/arm64-v8a/libgame.so"
file "$ROOT/app/src/main/jniLibs/arm64-v8a/libgame.so" || true
echo "build_native OK"
