LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := game_shared
LOCAL_MODULE_FILENAME := libgame

LOCAL_SRC_FILES := main.cpp \
    ../Classes/AppDelegate.cpp \
    ../Classes/StartScene.cpp \
    ../Classes/GameplayScene.cpp \
    ../Classes/BasicEnemy.cpp \
    ../Classes/PlayerCharacter.cpp \
    ../Classes/WaveCreator.cpp \
    ../Classes/MenuButton.cpp \
    ../Classes/MissDisplay.cpp \
    ../Classes/ObjCCalls.cpp

LOCAL_C_INCLUDES := $(LOCAL_PATH)/../Classes
LOCAL_WHOLE_STATIC_LIBRARIES := cocos2dx_static cocosdenshion_static
include $(BUILD_SHARED_LIBRARY)

# COCOS2DX_ROOT and OVERRIDES are passed by scripts/build_native.sh
$(call import-add-path,$(OVERRIDES))
$(call import-add-path,$(COCOS2DX_ROOT))
$(call import-add-path,$(COCOS2DX_ROOT)/cocos2dx/platform/third_party/android/prebuilt)
$(call import-module,CocosDenshion/android)
$(call import-module,cocos2dx)
