#ifndef __MISSDISPLAY_H__
#define __MISSDISPLAY_H__
#include "cocos2d.h"

// RECONSTRUCTED (APPROXIMATED): row of "miss.png" markers. The original symbols are
// setup / resetMisses / failedMisses. Verified: frame "miss.png" exists in enemyassets.plist and
// the HUD label text "MISSES: %d". The limit of 3 misses is NOT verified.
class MissDisplay : public cocos2d::CCNode {
public:
    static MissDisplay* create(cocos2d::CCNode* parent, int maxMisses);
    void setup(cocos2d::CCNode* parent);
    void resetMisses();
    void addMiss();
    bool failedMisses() const { return misses >= maxMisses; }
    int  getMisses() const { return misses; }
private:
    int misses;
    int maxMisses;
    cocos2d::CCArray* icons;
};
#endif
