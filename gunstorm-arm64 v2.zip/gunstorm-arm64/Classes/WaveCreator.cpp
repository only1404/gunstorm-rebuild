// Tier values below are DECODED from the original binary (docs/decode_wave_tables.py).
// The final entry of each table is an extra open-ended tier: the original has one more tier
// after level 150 that the decoder did not capture; it is approximated by repeating tier 5.
#include "WaveCreator.h"
#include <stdlib.h>

static const WaveTier kPistol[] = {
    {10, 0.5f, 0.5f, 0.0f, 0.0f, 100, 20, 0.2f, 1.5f, 2.0f, 1.5f},
    {25, 0.46f, 0.46f, 0.0f, 0.0f, 100, 20, 0.18f, 1.5f, 2.0f, 1.5f},
    {50, 0.42f, 0.42f, 0.0f, 0.0f, 100, 25, 0.16f, 1.5f, 2.0f, 1.5f},
    {100, 0.38f, 0.38f, 0.0f, 0.0f, 100, 26, 0.14f, 1.5f, 2.0f, 1.5f},
    {150, 0.3f, 0.3f, 0.0047f, 0.0047f, 100, 40, 0.08f, 1.15f, 2.0f, 1.5f},
    {0x7fffffff, 0.3f, 0.3f, 0.0047f, 0.0047f, 100, 40, 0.08f, 1.15f, 2.0f, 1.5f},
};

static const WaveTier kShotgun[] = {
    {10, 0.5f, 0.5f, 0.0f, 0.0f, 100, 20, 0.2f, 1.5f, 2.0f, 1.5f},
    {25, 0.43f, 0.43f, 0.0f, 0.0f, 100, 25, 0.17f, 1.5f, 2.0f, 1.5f},
    {50, 0.4f, 0.4f, 0.0f, 0.0f, 100, 30, 0.15f, 1.5f, 2.0f, 1.5f},
    {100, 0.36f, 0.36f, 0.0f, 0.0f, 100, 25, 0.14f, 1.5f, 2.0f, 1.5f},
    {150, 0.3f, 0.3f, 0.0047f, 0.0047f, 100, 35, 0.12f, 1.5f, 2.0f, 1.5f},
    {0x7fffffff, 0.3f, 0.3f, 0.0047f, 0.0047f, 100, 35, 0.12f, 1.5f, 2.0f, 1.5f},
};

static const WaveTier kBow[] = {
    {7, 0.55f, 0.55f, 0.0f, 0.0f, 100, 30, 0.252f, 1.5f, 2.0f, 1.5f},
    {25, 0.5f, 0.5f, 0.0f, 0.0f, 100, 30, 0.2f, 1.5f, 2.0f, 1.5f},
    {50, 0.45f, 0.45f, 0.0f, 0.0f, 100, 20, 0.18f, 1.5f, 2.0f, 1.5f},
    {100, 0.4f, 0.4f, 0.0f, 0.0f, 100, 25, 0.14f, 1.5f, 2.0f, 1.5f},
    {150, 0.34f, 0.34f, 0.0047f, 0.0047f, 100, 20, 0.09f, 1.5f, 2.0f, 1.5f},
    {0x7fffffff, 0.34f, 0.34f, 0.0047f, 0.0047f, 100, 20, 0.09f, 1.5f, 2.0f, 1.5f},
};


WaveCreator::WaveCreator() { reset(); }

void WaveCreator::reset() {
    waveRemaining = 0; clusterRemaining = 0; gapTimer = 1.0f; level = 1;
    apply(kPistol, sizeof(kPistol) / sizeof(kPistol[0]), 1);
}

void WaveCreator::apply(const WaveTier* tiers, int n, int lvl) {
    level = lvl;
    for (int i = 0; i < n; ++i) {
        if (lvl <= tiers[i].levelMax || i == n - 1) { tier = tiers[i]; break; }
    }
    waveRemaining = tier.enemiesInWave;
    clusterRemaining = 0;
}

void WaveCreator::createPistolWave(int lvl)  { apply(kPistol,  sizeof(kPistol)  / sizeof(kPistol[0]),  lvl); }
void WaveCreator::createShotgunWave(int lvl) { apply(kShotgun, sizeof(kShotgun) / sizeof(kShotgun[0]), lvl); }
void WaveCreator::createBowWave(int lvl)     { apply(kBow,     sizeof(kBow)     / sizeof(kBow[0]),     lvl); }

// APPROXIMATED: the intro text says "you can shoot two enemies", so clusters of 1-2 early,
// up to 3 from level 25 on. The real roll could not be recovered.
int WaveCreator::calculateClusterSize() {
    int maxSize = (level < 10) ? 2 : 3;
    int n = 1 + rand() % maxSize;
    if (n > waveRemaining) n = waveRemaining;
    clusterRemaining = n;
    return n;
}

float WaveCreator::calculateClusterGap() {
    float r = (float)rand() / (float)RAND_MAX;
    return tier.clusterGapMin + r * (tier.clusterGapMax - tier.clusterGapMin);
}

void WaveCreator::decrementClusterAndWave() {
    if (clusterRemaining > 0) --clusterRemaining;
    if (waveRemaining > 0) --waveRemaining;
}
