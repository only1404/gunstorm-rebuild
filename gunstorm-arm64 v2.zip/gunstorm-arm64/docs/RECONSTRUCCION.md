# Qué está recuperado, aproximado y pendiente

Leyenda: **V** = verificado con el binario/recursos originales · **A** = aproximado (comportamiento razonable, no confirmado) · **P** = pendiente.

## Motor
- V: Cocos2d-x **2.1.5**, CocosDenshion con OpenSL, tinyxml2, libpng 1.2.46, runtime Spine en C (`spAnimationState…`, sin envoltorio `CCSkeleton`).
- V: solo existe `lib/armeabi/libgame.so` (ARM 32 bits). El S24 Ultra no puede cargarlo → se recompila el motor y se reescribe el código del juego.
- P: Spine. No hay integración del runtime spine-c; se usan fotogramas estáticos (`logo_full`, `play`, `Stop`, …).

## Clases
| Clase | Estado | Detalle |
|---|---|---|
| `AppDelegate` | V/A | V: rutas `common/music/sfx` + `hd2`/`hd`, logs, init de `CCUserDefault`, carga de atlas, precarga de los 16 sonidos. A: tabla exacta de tamaño de pantalla → escala (el original tiene ~6 ramas con 0.5/0.85/0.9/1.1/1.35 y umbrales 1050/1090/1500); aquí: coordenadas lógicas de 1080 de alto, `hd2` si la altura ≥ 1300 px (los `hd2` miden exactamente el doble que `hd`). Nombres de claves de `UserDefault`: A. |
| `StartScene` | V/A | V: sonidos `intro`/`titlev2`/`playPressed`, clave `sfxOn`, `volumeOn/Off`, táctil por `ccTouchesBegan`. A: disposición. P: Spine, medallas, ranking. Quitados: Facebook/Twitter/ranking. |
| `GameplayScene` | V/A | V: flujo (`setupGameplay`, `beginSpawning` con «get ready…» a los 3.0 s, `buildWave`→`WaveCreator`, `spawnEnemy`/`allSpotsTaken`, `calculateShot`, pausa/reanudar, game over, estadísticas de por vida: kills/dummies/psychics/doble disparo), 6 posiciones (A–F) en rejilla 3×2, textos («tap enemies to shoot.», «you can shoot two enemies», «don't miss», «MISS!», «dishonor!», «MISSES: %d», «%d kills!», «+1», «score - %d», «TRIAL SCORE:», «TRIAL REACHED:», «RATING:», «best - », «KILLS - »), botones resume/retry/quit. A: reglas de puntuación (1 punto por baja), geometría de impacto, fórmula de nota, 3 fallos, fondo, posiciones. P: ads/compras, `adSkip*`, `purchase*`, `rankCheck` real, `spawnCluster`/`goatEscape`/modos especiales, `calculateAverage*` exactos. |
| `BasicEnemy` | V/A | V: fotogramas `Raised/Aimed/Dead/Headless/Shoot00-06`, partículas de sangre, métodos, fundido de 0.3 s al morir, huida de 0.2 s, tiempo de reacción por intervalo de animación. A: máquina de estados, duración de «Raised», animación de disparo. |
| `PlayerCharacter` | V/A | V: 21 combinaciones `Avatar*-{Fire,Recoil,Blank}`, `AvatarReset`, `AvatarDishonor`, `Avatar-Death00-06`, partícula `shotfromright.plist`. A: tiempos, posición. |
| `WaveCreator` | V/A | **V: las tablas numéricas de `createPistolWave/ShotgunWave/BowWave` (tramos de nivel ≤10/25/50/100/150 y todos sus valores) decodificadas del binario** (`docs/wave_tables.json`). A: el *significado* de cada campo y el cálculo de clústeres; el tramo por encima de nivel 150 repite el último decodificado. |
| `MenuButton` | A | El original busca `<nombre>-button.png`, que **no existe** en los atlas de este APK; aquí se dibuja texto con `gunstorm.fnt`. |
| `MissDisplay` | A | iconos `miss.png`; límite de fallos no verificado. |
| `ObjCCalls` | stub | Puente JNI a Chartboost/Facebook/Amazon/Google Play: retirado. |

## Recursos
V: atlas `.pvr.ccz` (PVR v2, RGBA4444 sin comprimir → funcionan en cualquier GPU), `.plist`, `.fnt`, 16 `.ogg`, partículas. `gunstorm.fnt` solo tiene minúsculas → el texto con mayúsculas usa `CCLabelTTF` (fuente del sistema).
