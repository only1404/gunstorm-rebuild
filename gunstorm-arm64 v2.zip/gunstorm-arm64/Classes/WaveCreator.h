#ifndef __WAVECREATOR_H__
#define __WAVECREATOR_H__

// WaveCreator: RECONSTRUCTED.
// VERIFIED (decoded from libgame.so, see docs/wave_tables.json): the numeric tier tables of
// createPistolWave / createShotgunWave / createBowWave (level thresholds and every value).
// APPROXIMATED: the *meaning* of each field (the original only stores them at member offsets
// 0x10..0x48; names below are educated guesses), and how clusters are rolled.
struct WaveTier {
    int   levelMax;        // tier applies while level <= levelMax (last tier = open-ended)
    float attackDelayMin;  // 0x10  seconds an enemy keeps aiming before it shoots (guess)
    float attackDelayMax;  // 0x14
    float extra20;         // 0x20  only present in the last tier (0.0047)
    float extra24;         // 0x24
    int   field28;         // 0x28  = 100 in every tier
    int   enemiesInWave;   // 0x38  (guess)
    float spawnGap;        // 0x3c  seconds between enemies inside a cluster (guess)
    float clusterGapMin;   // 0x40
    float clusterGapMax;   // 0x44
    float field48;         // 0x48
};

class WaveCreator {
public:
    WaveCreator();
    void reset();

    void createPistolWave(int level);
    void createShotgunWave(int level);
    void createBowWave(int level);

    int   calculateClusterSize();      // APPROXIMATED
    float calculateClusterGap();       // APPROXIMATED
    void  setNumberOfEnemiesInCluster(int n) { clusterRemaining = n; }
    void  decrementClusterAndWave();
    void  decrementGap(float dt)       { if (gapTimer > 0) gapTimer -= dt; }
    float getGapNumber() const         { return gapTimer; }
    void  setGap(float g)              { gapTimer = g; }

    WaveTier tier;
    int   waveRemaining;     // enemies left to spawn in the current wave
    int   clusterRemaining;  // enemies left in the current cluster
    float gapTimer;          // time until the next spawn
    int   level;

private:
    void apply(const WaveTier* tiers, int n, int level);
};
#endif
