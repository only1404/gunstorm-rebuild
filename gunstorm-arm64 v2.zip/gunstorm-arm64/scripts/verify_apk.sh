#!/usr/bin/env bash
# Static checks only (does NOT run the game). Real testing needs a device.
set -euo pipefail
source "$(dirname "$0")/env.sh"
APK="${1:-$ROOT/app/build/outputs/apk/debug/app-debug.apk}"
BT="$(ls -d "$ANDROID_SDK_ROOT"/build-tools/* | sort -V | tail -1)"
echo "APK: $APK"
"$BT/apksigner" verify --verbose "$APK"
unzip -l "$APK" | grep -E 'lib/arm64-v8a/libgame.so|assets/hd2/enemyassets.pvr.ccz|classes.dex'
"$BT/aapt2" dump badging "$APK" | grep -E "package:|native-code|sdkVersion|targetSdkVersion"
echo "verify OK (static)"
