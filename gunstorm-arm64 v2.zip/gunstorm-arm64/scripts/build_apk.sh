#!/usr/bin/env bash
# Local end-to-end build: deps -> third-party -> native -> Gradle debug APK.
set -euo pipefail
source "$(dirname "$0")/env.sh"
"$ROOT/scripts/fetch_deps.sh"
"$ROOT/scripts/build_thirdparty.sh"
"$ROOT/scripts/build_native.sh"
cd "$ROOT"
gradle --no-daemon :app:assembleDebug      # Gradle 8.4 + JDK 17 required
ls -la app/build/outputs/apk/debug/
