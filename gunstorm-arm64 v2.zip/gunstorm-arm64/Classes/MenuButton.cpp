#include "MenuButton.h"
using namespace cocos2d;

MenuButton* MenuButton::create(const std::string& name, CCPoint pos, CCNode* parent) {
    MenuButton* b = new MenuButton();
    b->init();
    b->autorelease();
    b->name = name;
    b->active = false;
    b->label = CCLabelBMFont::create(name.c_str(), "gunstorm.fnt");
    b->addChild(b->label);
    b->setPosition(pos);
    b->setVisible(false);
    parent->addChild(b, 100);
    return b;
}

void MenuButton::setActive(bool a) {
    active = a;
    setVisible(a);
    displayPressedFrame(false);
}

void MenuButton::displayPressedFrame(bool pressed) {
    label->setColor(pressed ? ccc3(255, 200, 60) : ccc3(255, 255, 255));
    label->setScale(pressed ? 1.1f : 1.0f);
}

bool MenuButton::containsPoint(const CCPoint& p) {
    if (!active) return false;
    CCSize s = label->getContentSize();
    CCPoint c = getPosition();
    CCRect r(c.x - s.width * 0.75f, c.y - s.height * 0.9f, s.width * 1.5f, s.height * 1.8f);
    return r.containsPoint(p);
}
