import re,struct,json,sys
so=open('/home/claude/work/apk/lib/armeabi/libgame.so','rb').read()
# LOAD mapping: assume vaddr==offset for text (verified below via readelf output)
def word(a): return struct.unpack('<I',so[a:a+4])[0]
def fl(a): return struct.unpack('<f',so[a:a+4])[0]
lines=open('/home/claude/work/anal/analisis-original/so_analysis/disassembly_arm32.txt').read().split('\n')
def func(name):
    out=[];p=False
    for l in lines:
        if l.endswith(f'<{name}>:'): p=True; continue
        if p:
            if re.match(r'^[0-9a-f]{8} <',l): break
            out.append(l)
    return out
def tiers(name):
    regs={};res=[];cur=None;pending={}
    for l in func(name):
        m=re.match(r'\s+([0-9a-f]+):\s+[0-9a-f]{8}\s+\t(\w+)\t?(.*)',l)
        if not m: continue
        addr,op,args=m.groups()
        a=re.match(r'r(\d+), #(\d+)$',args) if op=='mov' else None
        if op=='mov' and a: regs[a.group(1)]=('i',int(a.group(2)));continue
        if op=='cmp':
            c=re.match(r'r3, #(\d+)',args)
            if c: cur={'le':int(c.group(1)),'f':{}};res.append(cur)
            continue
        if op=='ldr':
            c=re.match(r'r(\d+), \[pc, #0x[0-9a-f]+\]\s+@ 0x([0-9a-f]+)',args)
            if c: regs[c.group(1)]=('w',word(int(c.group(2),16)));continue
        if op=='str':
            c=re.match(r'r(\d+), \[r3, #(0x[0-9a-f]+|\d+)\]',args)
            if c and cur is not None and c.group(1) in regs:
                off=int(c.group(2),16) if c.group(2).startswith('0x') else int(c.group(2))
                k,v=regs[c.group(1)]
                cur['f'][off]=v if k=='i' else {'raw':v,'f32':round(struct.unpack('<f',struct.pack('<I',v))[0],4)}
    return res
for n in ['createPistolWave','createShotgunWave','createBowWave']:
    t=tiers(f'_ZN11WaveCreator{len(n)}{n}Ei')
    print('==',n,len(t),'tiers')
    for x in t[:12]:
        print(' level<=',x['le'],{hex(k):(v if isinstance(v,int) else v['f32']) for k,v in sorted(x['f'].items())})
