#!/usr/bin/env bash
# Applies patches/*.patch (unified diffs, -p1) to third_party/cocos2d-x, once each.
set -euo pipefail
source "$(dirname "$0")/env.sh"
cd "$COCOS2DX_ROOT"
shopt -s nullglob
for p in "$ROOT"/patches/*.patch; do
  marker=".applied-$(basename "$p")"
  [ -f "$marker" ] && continue
  echo "   patch $(basename "$p")"
  patch -p1 < "$p"
  touch "$marker"
done
