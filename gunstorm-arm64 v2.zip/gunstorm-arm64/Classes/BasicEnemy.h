#ifndef __BASICENEMY_H__
#define __BASICENEMY_H__
#include "cocos2d.h"
#include <string>

// BasicEnemy: RECONSTRUCTED.
// VERIFIED: frame names <Name>-{Raised,Aimed,Dead,Headless,Shoot00..06}.png, blood particle
// files blood_<X>.plist / blood_<X>_headless.plist, public method set (initiate, reset, update,
// setAttackDelay, spawnIn, hasBeenHit, calculateReactionTime, killEnemy, escape, gameoverFade),
// killEnemy fades out over 0.3 s, escape moves out over 0.2 s, reaction time derived from the
// director's animation interval (frame-counted).
// APPROXIMATED: state machine details, raise duration, shoot animation speed, spawn motion.
class GameplayScene;

class BasicEnemy : public cocos2d::CCSprite {
public:
    enum State { IDLE, SPAWNING, RAISED, AIMED, SHOOTING, DEAD, ESCAPING };

    static BasicEnemy* createWithSpriteFrameName(const char* raisedFrame, int spot);
    void initiate(cocos2d::CCNode* parent);
    void reset();
    void update();                       // call once per frame
    void setAttackDelay(float seconds)   { attackDelay = seconds; }
    void setRaisedDuration(float s)      { raisedDuration = s; }
    void spawnIn();
    bool hasBeenHit();                   // true when the enemy was in the AIMED state
    float calculateReactionTime();       // seconds spent aimed before being hit
    void killEnemy(bool headshot);
    void escape();
    void gameoverFade();

    State getState() const { return state; }
    bool  isActive() const { return state == RAISED || state == AIMED; }
    int   getSpot() const  { return spot; }
    void  setTarget(GameplayScene* s) { scene = s; }
    cocos2d::CCPoint getHome() const  { return home; }
    void  setHome(const cocos2d::CCPoint& p) { home = p; }

private:
    void onShotFinished();
    void finishReset();
    std::string baseName;    // "EnemyA" / "EnemyB" / "EnemyC"
    char kind;               // 'A','B','C'
    int spot;
    State state;
    float stateTime;
    float attackDelay;
    float raisedDuration;
    float reactionTime;
    cocos2d::CCPoint home;
    GameplayScene* scene;
    cocos2d::CCParticleSystemQuad* blood;
    cocos2d::CCParticleSystemQuad* bloodHeadless;
};
#endif
