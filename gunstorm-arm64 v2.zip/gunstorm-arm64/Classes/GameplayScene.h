#ifndef __GAMEPLAYSCENE_H__
#define __GAMEPLAYSCENE_H__
#include "cocos2d.h"
#include <vector>
#include <string>

class BasicEnemy;
class PlayerCharacter;
class WaveCreator;
class MissDisplay;
class MenuButton;

// GameplayScene: RECONSTRUCTED, mostly APPROXIMATED.
// VERIFIED from the original: method names/flow (setupGameplay, beginSpawning "get ready..." after
// 3.0 s, buildWave -> WaveCreator, spawnEnemy/allSpotsTaken, calculateShot, bullet/yell/shot
// sounds, showreactiongrade strings "MISS!", "dishonor!", "MISSES: %d", "%d kills!", "+1",
// score label "score - %d", game-over strings, buttons "resume"/"retry"/"quit", lifetime stats
// (kills, dummies, psychics, double shots), six spots (A-F) in a 3x2 grid, intro texts.
// NOT recovered: exact scoring rules, grade formula, shot hit geometry, UI layout, background art.
class GameplayScene : public cocos2d::CCLayer {
public:
    static cocos2d::CCScene* scene();
    CREATE_FUNC(GameplayScene);
    virtual bool init();
    virtual ~GameplayScene();
    static GameplayScene* current();

    // lifecycle
    void setupGameplay();
    void setupUI();
    void setupBackground();
    void introduction0();
    void introduction1();
    void introduction2();
    void introduction3();
    void beginSpawning();
    void startPlaying();
    void resetLevel();
    void triggerRestart();
    void quitScene();
    void pauseGame();
    void resumeGame();

    // waves
    void buildWave();
    void setupWave();
    void enemyUpdate(float dt);
    void spawnEnemy();
    void buildAndSpawnEnemy();
    bool allSpotsTaken();
    bool noEnemiesActive();

    // input
    virtual void ccTouchesBegan(cocos2d::CCSet* touches, cocos2d::CCEvent* event);
    virtual void ccTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* event);
    virtual void keyBackClicked();
    void calculateShot();
    void menubuttonCheck(const cocos2d::CCPoint& p);

    // callbacks from enemies
    void onEnemyShotPlayer(BasicEnemy* e);

    // scoring / UI
    void addToScore(int n);
    void showreactiongrade(float reactionSeconds, int points);
    void showdoublereactions(int a, int b);
    std::string calculateReactionGrade();
    void flashInScreenLabelWithString(const std::string& s);
    void hideScreenLabels();
    void removeNode(cocos2d::CCNode* n);
    void bulletHitSound();
    void bulletMissSound();
    void playerShootSound();
    void playerShootHeadlessSound();
    void yellSound();

    // game over
    void gameoverRoutine();
    void gameoverStats();
    void checkGameoverButtons(const cocos2d::CCPoint& p);
    void rankCheck();

    // persistence
    void loadLifetimeStats();
    void saveLifetimeStats();
    void incrementLifetimeKills()       { ++lifetimeKills; }
    void incrementLifetimeDoubleShots() { ++lifetimeDoubleShots; }

private:
    enum Mode { MODE_INTRO, MODE_PLAY, MODE_PAUSED, MODE_GAMEOVER };
    int spotAtPoint(const cocos2d::CCPoint& p);
    cocos2d::CCPoint spotPosition(int spot);

    Mode mode;
    PlayerCharacter* player;
    WaveCreator* waves;
    MissDisplay* misses;
    cocos2d::CCArray* enemies;          // 6 BasicEnemy, index == spot
    std::vector<cocos2d::CCPoint> pendingShots;
    std::vector<float> reactions;
    MenuButton* btnResume; MenuButton* btnRetry; MenuButton* btnQuit;
    cocos2d::CCSprite* stopButton;
    cocos2d::CCLabelBMFont* scoreLabel;
    cocos2d::CCNode* statsNode;

    int score, kills, level, bestScore;
    int lifetimeKills, lifetimeDummies, lifetimePsychics, lifetimeDoubleShots;
    float spawnTimer;
    bool clusterActive;
    bool introSeen;
};
#endif
