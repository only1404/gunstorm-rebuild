#include "PlayerCharacter.h"
#include <stdio.h>
using namespace cocos2d;

static const char* kCombos[21] = {
    "A","AB","AC","AD","AE","AF","B","BC","BD","BE","BF","C","CD","CE","CF","D","DE","DF","E","EF","F"
};

PlayerCharacter* PlayerCharacter::create() {
    PlayerCharacter* p = new PlayerCharacter();
    if (p && p->initWithSpriteFrameName("AvatarReset.png")) {
        p->autorelease();
        p->animations = CCArray::create();
        p->animations->retain();
        p->deathAnim = NULL;
        p->muzzle = NULL;
        return p;
    }
    delete p;
    return NULL;
}

void PlayerCharacter::initiate(CCNode* parent) {
    CCSize win = CCDirector::sharedDirector()->getWinSize();
    setAnchorPoint(ccp(0.5f, 0.0f));
    setPosition(ccp(win.width * 0.5f, 0.0f));      // APPROXIMATED position
    parent->addChild(this, 10);
    muzzle = CCParticleSystemQuad::create("shotfromright.plist");
    if (muzzle) {
        muzzle->stopSystem();
        muzzle->setPosition(ccp(win.width * 0.55f, win.height * 0.2f));
        parent->addChild(muzzle, 11);
    }
    setupAnimations();
}

void PlayerCharacter::setupAnimations() {
    for (int i = 0; i < 21; ++i) addAnimationWithString(kCombos[i]);
    addDeathAnimation();
}

void PlayerCharacter::addAnimationWithString(const std::string& combo) {
    CCSpriteFrameCache* fc = CCSpriteFrameCache::sharedSpriteFrameCache();
    CCAnimation* a = CCAnimation::create();
    const char* suffix[3] = { "-Fire.png", "-Recoil.png", "-Blank.png" };
    for (int i = 0; i < 3; ++i) {
        CCSpriteFrame* f = fc->spriteFrameByName(("Avatar" + combo + suffix[i]).c_str());
        if (f) a->addSpriteFrame(f);
    }
    a->setDelayPerUnit(0.07f);       // APPROXIMATED
    animations->addObject(a);
}

void PlayerCharacter::addDeathAnimation() {
    CCSpriteFrameCache* fc = CCSpriteFrameCache::sharedSpriteFrameCache();
    deathAnim = CCAnimation::create();
    for (int i = 0; i <= 6; ++i) {
        char name[32];
        sprintf(name, "Avatar-Death%02d.png", i);
        CCSpriteFrame* f = fc->spriteFrameByName(name);
        if (f) deathAnim->addSpriteFrame(f);
    }
    deathAnim->setDelayPerUnit(0.08f);   // APPROXIMATED
    deathAnim->retain();
}

void PlayerCharacter::resetPoses() { stopAllActions(); playResetPose(); }

int PlayerCharacter::comboIndex(int a, int b) {
    if (b < 0) { b = a; }
    if (a > b) { int t = a; a = b; b = t; }
    for (int i = 0; i < 21; ++i) {
        std::string c = kCombos[i];
        if (a == b) { if (c.size() == 1 && c[0] == 'A' + a) return i; }
        else if (c.size() == 2 && c[0] == 'A' + a && c[1] == 'A' + b) return i;
    }
    return 0;
}

void PlayerCharacter::playAnimation(int id) {
    if (id < 0 || id >= (int)animations->count()) return;
    stopAllActions();
    if (muzzle) muzzle->resetSystem();
    CCAnimation* a = (CCAnimation*)animations->objectAtIndex(id);
    runAction(CCSequence::create(CCAnimate::create(a),
                                 CCDelayTime::create(0.12f),
                                 CCCallFunc::create(this, callfunc_selector(PlayerCharacter::playResetPose)),
                                 NULL));
}

void PlayerCharacter::playResetPose() {
    CCSpriteFrame* f = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("AvatarReset.png");
    if (f) setDisplayFrame(f);
}

void PlayerCharacter::playResetPoseWithDelay(float d) {
    runAction(CCSequence::create(CCDelayTime::create(d),
        CCCallFunc::create(this, callfunc_selector(PlayerCharacter::playResetPose)), NULL));
}

void PlayerCharacter::playDishonorPose() {
    stopAllActions();
    CCSpriteFrame* f = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("AvatarDishonor.png");
    if (f) setDisplayFrame(f);
    playResetPoseWithDelay(0.6f);   // APPROXIMATED
}

void PlayerCharacter::playDishonorPoseWithDelay(float d) {
    runAction(CCSequence::create(CCDelayTime::create(d),
        CCCallFunc::create(this, callfunc_selector(PlayerCharacter::playDishonorPose)), NULL));
}

void PlayerCharacter::playDeathAnimationWithFlip(bool flip) {
    stopAllActions();
    setFlipX(flip);
    if (deathAnim) runAction(CCAnimate::create(deathAnim));
}
