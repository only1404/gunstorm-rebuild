// See GameplayScene.h for what is verified vs approximated.
#include "GameplayScene.h"
#include "StartScene.h"
#include "BasicEnemy.h"
#include "PlayerCharacter.h"
#include "WaveCreator.h"
#include "MissDisplay.h"
#include "MenuButton.h"
#include "ObjCCalls.h"
#include "SimpleAudioEngine.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <algorithm>

using namespace cocos2d;
using namespace CocosDenshion;

static GameplayScene* s_current = NULL;
static const int   kMaxMisses = 3;             // APPROXIMATED
static const float kTextZ = 80;

// Bitmap font (gunstorm.fnt) only contains lowercase glyphs, so any text with capitals is
// drawn with a system font (the original does the same for strings like "TRIAL SCORE:").
static CCNode* makeText(const std::string& s, float bmScale = 1.0f, float ttfSize = 54.0f) {
    bool upper = false;
    for (size_t i = 0; i < s.size(); ++i) if (isupper((unsigned char)s[i])) upper = true;
    if (upper) {
        CCLabelTTF* t = CCLabelTTF::create(s.c_str(), "Arial", ttfSize);
        return t;
    }
    CCLabelBMFont* b = CCLabelBMFont::create(s.c_str(), "gunstorm.fnt");
    if (b) b->setScale(bmScale);
    return b;
}
static void setText(CCNode* n, const std::string& s) {
    CCLabelProtocol* p = dynamic_cast<CCLabelProtocol*>(n);
    if (p) p->setString(s.c_str());
}
static std::string fmt(const char* f, int a) { char b[96]; snprintf(b, sizeof(b), f, a); return b; }

CCScene* GameplayScene::scene() {
    CCScene* s = CCScene::create();
    s->addChild(GameplayScene::create());
    return s;
}
GameplayScene* GameplayScene::current() { return s_current; }

GameplayScene::~GameplayScene() {
    if (s_current == this) s_current = NULL;
    CC_SAFE_RELEASE(enemies);
    delete waves;
}

bool GameplayScene::init() {
    if (!CCLayer::init()) return false;
    s_current = this;
    player = NULL; waves = NULL; misses = NULL; enemies = NULL;
    btnResume = btnRetry = btnQuit = NULL; stopButton = NULL; scoreLabel = NULL; statsNode = NULL;
    score = kills = 0; level = 1; bestScore = 0;
    lifetimeKills = lifetimeDummies = lifetimePsychics = lifetimeDoubleShots = 0;
    spawnTimer = 0; clusterActive = false;
    mode = MODE_INTRO;

    setTouchEnabled(true);
    setKeypadEnabled(true);
    loadLifetimeStats();
    setupBackground();
    setupGameplay();
    setupUI();
    rankCheck();
    ObjCCalls::setAtGameplayScene(true);

    introSeen = CCUserDefault::sharedUserDefault()->getBoolForKey("introSeen", false);
    if (!introSeen) introduction0();
    else beginSpawning();
    return true;
}

void GameplayScene::setupBackground() {
    // APPROXIMATED: the original background art is not identifiable among the atlas frames.
    CCLayerColor* bg = CCLayerColor::create(ccc4(28, 20, 15, 255));
    addChild(bg, -10);
    CCSize win = CCDirector::sharedDirector()->getWinSize();
    CCLayerColor* ground = CCLayerColor::create(ccc4(60, 42, 28, 255), win.width, win.height * 0.36f);
    addChild(ground, -9);
}

CCPoint GameplayScene::spotPosition(int spot) {
    CCSize w = CCDirector::sharedDirector()->getWinSize();
    int col = spot % 3, row = spot / 3;
    return ccp(w.width * (2 * col + 1) / 6.0f, row == 0 ? w.height * 0.33f : w.height * 0.50f);
}

void GameplayScene::setupGameplay() {
    waves = new WaveCreator();
    player = PlayerCharacter::create();
    player->initiate(this);
    reorderChild(player, 3);

    enemies = CCArray::create();
    enemies->retain();
    static const char* names[3] = { "EnemyA-Raised.png", "EnemyB-Raised.png", "EnemyC-Raised.png" };
    for (int i = 0; i < 6; ++i) {
        BasicEnemy* e = BasicEnemy::createWithSpriteFrameName(names[i % 3], i);
        e->setHome(spotPosition(i));
        e->setTarget(this);
        e->initiate(this);
        reorderChild(e, i < 3 ? 7 : 5);       // front row drawn over back row
        enemies->addObject(e);
    }
    misses = MissDisplay::create(this, kMaxMisses);
}

void GameplayScene::setupUI() {
    CCSize win = CCDirector::sharedDirector()->getWinSize();
    scoreLabel = CCLabelBMFont::create("score - 0", "gunstorm.fnt");
    scoreLabel->setAnchorPoint(ccp(0.5f, 1.0f));
    scoreLabel->setPosition(ccp(win.width * 0.5f, win.height - 30.0f));
    addChild(scoreLabel, kTextZ);

    stopButton = CCSprite::createWithSpriteFrameName("Stop.png");
    if (stopButton) {
        stopButton->setPosition(ccp(90.0f, win.height - 90.0f));
        addChild(stopButton, kTextZ);
    }
    btnResume = MenuButton::create("resume", ccp(win.width * 0.5f, win.height * 0.62f), this);
    btnRetry  = MenuButton::create("retry",  ccp(win.width * 0.5f, win.height * 0.46f), this);
    btnQuit   = MenuButton::create("quit",   ccp(win.width * 0.5f, win.height * 0.30f), this);
}

// ---- intro (shown on first run only; texts are verified) ----
void GameplayScene::introduction0() {
    mode = MODE_INTRO;
    SimpleAudioEngine::sharedEngine()->playEffect("spotlight.ogg");
    runAction(CCSequence::create(CCDelayTime::create(1.2f),
        CCCallFunc::create(this, callfunc_selector(GameplayScene::introduction1)), NULL));
}
void GameplayScene::introduction1() {
    flashInScreenLabelWithString("tap enemies to shoot.");
    runAction(CCSequence::create(CCDelayTime::create(2.4f),
        CCCallFunc::create(this, callfunc_selector(GameplayScene::introduction2)), NULL));
}
void GameplayScene::introduction2() {
    flashInScreenLabelWithString("you can shoot two enemies");
    runAction(CCSequence::create(CCDelayTime::create(2.4f),
        CCCallFunc::create(this, callfunc_selector(GameplayScene::introduction3)), NULL));
}
void GameplayScene::introduction3() {
    flashInScreenLabelWithString("don't miss");
    CCUserDefault::sharedUserDefault()->setBoolForKey("introSeen", true);
    CCUserDefault::sharedUserDefault()->flush();
    runAction(CCSequence::create(CCDelayTime::create(2.0f),
        CCCallFunc::create(this, callfunc_selector(GameplayScene::beginSpawning)), NULL));
}

void GameplayScene::beginSpawning() {
    mode = MODE_INTRO;
    player->playResetPose();
    flashInScreenLabelWithString("get ready...");
    // original: schedule(selector, 3.0f)
    runAction(CCSequence::create(CCDelayTime::create(3.0f),
        CCCallFunc::create(this, callfunc_selector(GameplayScene::startPlaying)), NULL));
}

void GameplayScene::startPlaying() {
    mode = MODE_PLAY;
    level = 1;
    buildWave();
    schedule(schedule_selector(GameplayScene::enemyUpdate));
}

void GameplayScene::buildWave() {
    waves->createPistolWave(level);          // verified: buildWave calls createPistolWave
    waves->setGap(1.0f);
    waves->clusterRemaining = 0;
    if (level > 1) flashInScreenLabelWithString(fmt("wave %d", level));
}
void GameplayScene::setupWave() { buildWave(); }

// ---- wave/enemy flow ----
bool GameplayScene::allSpotsTaken() {
    for (unsigned i = 0; i < enemies->count(); ++i)
        if (((BasicEnemy*)enemies->objectAtIndex(i))->getState() == BasicEnemy::IDLE) return false;
    return true;
}
bool GameplayScene::noEnemiesActive() {
    for (unsigned i = 0; i < enemies->count(); ++i)
        if (((BasicEnemy*)enemies->objectAtIndex(i))->getState() != BasicEnemy::IDLE) return false;
    return true;
}

void GameplayScene::enemyUpdate(float dt) {
    if (mode != MODE_PLAY) return;
    for (unsigned i = 0; i < enemies->count(); ++i) ((BasicEnemy*)enemies->objectAtIndex(i))->update();
    if (mode != MODE_PLAY) return;             // an enemy shot may have ended the game

    waves->decrementGap(dt);
    if (waves->waveRemaining <= 0 && noEnemiesActive()) {
        ++level;
        buildWave();
        return;
    }
    if (waves->getGapNumber() <= 0 && waves->waveRemaining > 0 && !allSpotsTaken()) {
        if (waves->clusterRemaining <= 0) waves->calculateClusterSize();
        spawnEnemy();
        waves->decrementClusterAndWave();
        if (waves->clusterRemaining > 0) waves->setGap(waves->tier.spawnGap);
        else waves->setGap(waves->calculateClusterGap());
    }
}

void GameplayScene::spawnEnemy() {
    std::vector<int> free;
    for (unsigned i = 0; i < enemies->count(); ++i)
        if (((BasicEnemy*)enemies->objectAtIndex(i))->getState() == BasicEnemy::IDLE) free.push_back((int)i);
    if (free.empty()) return;
    BasicEnemy* e = (BasicEnemy*)enemies->objectAtIndex(free[rand() % free.size()]);
    float speedUp = waves->tier.attackDelayMin / 0.5f;           // faster at higher tiers (approximation)
    e->setAttackDelay(waves->tier.attackDelayMin);
    e->setRaisedDuration((0.7f + (rand() % 100) / 100.0f * 0.9f) * speedUp);
    e->spawnIn();
}
void GameplayScene::buildAndSpawnEnemy() { spawnEnemy(); }

// ---- input ----
int GameplayScene::spotAtPoint(const CCPoint& p) {
    for (unsigned i = 0; i < enemies->count(); ++i) {              // spots 0-2 first = front row
        BasicEnemy* e = (BasicEnemy*)enemies->objectAtIndex(i);
        if (!e->isActive() && e->getState() != BasicEnemy::SHOOTING) continue;
        CCRect r = e->boundingBox();
        r.origin.x -= r.size.width * 0.2f;  r.size.width  *= 1.4f;
        r.origin.y -= r.size.height * 0.1f; r.size.height *= 1.2f;
        if (r.containsPoint(p)) return (int)i;
    }
    return -1;
}

void GameplayScene::ccTouchesBegan(CCSet* touches, CCEvent*) {
    for (CCSetIterator it = touches->begin(); it != touches->end(); ++it) {
        CCTouch* t = (CCTouch*)(*it);
        CCPoint p = t->getLocation();
        if (mode == MODE_GAMEOVER) { checkGameoverButtons(p); continue; }
        if (mode == MODE_PAUSED)   { menubuttonCheck(p); continue; }
        if (mode != MODE_PLAY) continue;
        if (stopButton && stopButton->boundingBox().containsPoint(p)) { pauseGame(); return; }
        pendingShots.push_back(p);
    }
    if (!pendingShots.empty()) calculateShot();
}
void GameplayScene::ccTouchesEnded(CCSet*, CCEvent*) {
    if (btnResume) btnResume->displayPressedFrame(false);
    if (btnRetry)  btnRetry->displayPressedFrame(false);
    if (btnQuit)   btnQuit->displayPressedFrame(false);
}
void GameplayScene::keyBackClicked() {
    if (mode == MODE_PLAY) pauseGame();
    else if (mode == MODE_PAUSED) resumeGame();
    else quitScene();
}

void GameplayScene::calculateShot() {
    std::vector<CCPoint> shots;
    shots.swap(pendingShots);
    std::vector<int> killed;
    bool headshot = false, missed = false, dishonor = false;
    float reaction = 0;

    for (size_t i = 0; i < shots.size() && i < 2; ++i) {           // at most two simultaneous shots
        int spot = spotAtPoint(shots[i]);
        if (spot < 0) { missed = true; ++lifetimePsychics; continue; }
        BasicEnemy* e = (BasicEnemy*)enemies->objectAtIndex(spot);
        if (e->getState() == BasicEnemy::AIMED) {
            reaction = e->calculateReactionTime();
            e->hasBeenHit();
            bool hs = shots[i].y > e->getPositionY() + e->boundingBox().size.height * 0.7f;
            headshot = headshot || hs;
            e->killEnemy(hs);
            killed.push_back(spot);
            reactions.push_back(reaction);
        } else if (e->getState() == BasicEnemy::RAISED) {          // shot before it aimed
            dishonor = true; ++lifetimeDummies;
            e->escape();
        }
    }

    if (!killed.empty()) {
        int n = (int)killed.size();
        kills += n; lifetimeKills += n;
        addToScore(n);
        if (n == 2) { ++lifetimeDoubleShots; showdoublereactions(killed[0], killed[1]); }
        else showreactiongrade(reaction, n);
        if (headshot) playerShootHeadlessSound(); else playerShootSound();
        bulletHitSound();
        yellSound();
        player->playAnimation(PlayerCharacter::comboIndex(killed[0], n == 2 ? killed[1] : -1));
    }
    if (missed || dishonor) {
        if (dishonor) { player->playDishonorPose(); flashInScreenLabelWithString("dishonor!"); }
        else { bulletMissSound(); flashInScreenLabelWithString("MISS!"); }
        misses->addMiss();
        if (misses->failedMisses()) gameoverRoutine();
    }
}

void GameplayScene::onEnemyShotPlayer(BasicEnemy* e) {
    if (mode != MODE_PLAY) return;
    SimpleAudioEngine::sharedEngine()->playEffect("enemy_shoot.ogg");
    player->playDeathAnimationWithFlip(e->getSpot() % 3 == 2);
    gameoverRoutine();
}

// ---- scoring / UI helpers ----
void GameplayScene::addToScore(int n) {
    score += n;
    if (scoreLabel) scoreLabel->setString(fmt("score - %d", score).c_str());
}

void GameplayScene::showreactiongrade(float t, int) {
    CCNode* l = makeText("+1", 1.0f);
    if (!l) return;
    CCSize w = CCDirector::sharedDirector()->getWinSize();
    l->setPosition(ccp(w.width * 0.5f, w.height * 0.8f));
    addChild(l, kTextZ);
    l->runAction(CCSequence::create(CCMoveBy::create(0.6f, ccp(0, 60)), CCCallFuncN::create(this, callfuncN_selector(GameplayScene::removeNode)), NULL));
}
void GameplayScene::showdoublereactions(int, int) {
    CCNode* l = makeText("2 kills!", 1.0f);
    if (!l) return;
    CCSize w = CCDirector::sharedDirector()->getWinSize();
    l->setPosition(ccp(w.width * 0.5f, w.height * 0.8f));
    addChild(l, kTextZ);
    l->runAction(CCSequence::create(CCMoveBy::create(0.8f, ccp(0, 60)), CCCallFuncN::create(this, callfuncN_selector(GameplayScene::removeNode)), NULL));
}

std::string GameplayScene::calculateReactionGrade() {
    if (reactions.empty()) return "N/A";
    float sum = 0; for (size_t i = 0; i < reactions.size(); ++i) sum += reactions[i];
    float avg = sum / reactions.size();
    float pct = 100.0f * (1.0f - avg / std::max(0.05f, waves->tier.attackDelayMin));   // APPROXIMATED
    if (pct < 0) pct = 0; if (pct > 100) pct = 100;
    char b[16]; snprintf(b, sizeof(b), "%d%%", (int)pct);
    return b;
}

void GameplayScene::flashInScreenLabelWithString(const std::string& s) {
    CCNode* l = makeText(s, 1.2f);
    if (!l) return;
    CCSize w = CCDirector::sharedDirector()->getWinSize();
    l->setPosition(ccp(w.width * 0.5f, w.height * 0.86f));
    addChild(l, kTextZ);
    CCSprite* dummy = NULL; (void)dummy;
    l->runAction(CCSequence::create(CCDelayTime::create(1.4f), CCCallFuncN::create(this, callfuncN_selector(GameplayScene::removeNode)), NULL));
}
void GameplayScene::hideScreenLabels() {}
void GameplayScene::removeNode(CCNode* n) { if (n) n->removeFromParentAndCleanup(true); }

void GameplayScene::bulletHitSound()  { /* original: hit sound; no dedicated file -> shot_* covers it */ }
void GameplayScene::bulletMissSound() { SimpleAudioEngine::sharedEngine()->playEffect("miss.ogg"); }
void GameplayScene::playerShootSound() {
    static const char* f[3] = { "shot_1.ogg", "shot_2.ogg", "shot_3.ogg" };
    SimpleAudioEngine::sharedEngine()->playEffect(f[rand() % 3]);
}
void GameplayScene::playerShootHeadlessSound() { SimpleAudioEngine::sharedEngine()->playEffect("shot_headless.ogg"); }
void GameplayScene::yellSound() {
    static const char* f[4] = { "yell_1.ogg", "yell_2.ogg", "yell_3.ogg", "yell_4.ogg" };
    SimpleAudioEngine::sharedEngine()->playEffect(f[rand() % 4]);
}

// ---- pause / restart / quit ----
void GameplayScene::pauseGame() {
    if (mode != MODE_PLAY) return;
    mode = MODE_PAUSED;
    CCDirector::sharedDirector()->pause();
    btnResume->setActive(true); btnRetry->setActive(true); btnQuit->setActive(true);
}
void GameplayScene::resumeGame() {
    CCDirector::sharedDirector()->resume();
    btnResume->setActive(false); btnRetry->setActive(false); btnQuit->setActive(false);
    if (mode == MODE_PAUSED) mode = MODE_PLAY;
}
void GameplayScene::menubuttonCheck(const CCPoint& p) {
    if (btnResume->containsPoint(p))      { btnResume->displayPressedFrame(true); resumeGame(); }
    else if (btnRetry->containsPoint(p))  { btnRetry->displayPressedFrame(true);  triggerRestart(); }
    else if (btnQuit->containsPoint(p))   { btnQuit->displayPressedFrame(true);   quitScene(); }
}
void GameplayScene::triggerRestart() {
    CCDirector::sharedDirector()->resume();
    saveLifetimeStats();
    CCDirector::sharedDirector()->replaceScene(GameplayScene::scene());
}
void GameplayScene::resetLevel() { triggerRestart(); }   // original resets in place; we rebuild the scene
void GameplayScene::quitScene() {
    CCDirector::sharedDirector()->resume();
    saveLifetimeStats();
    ObjCCalls::setAtGameplayScene(false);
    CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(0.4f, StartScene::scene()));
}

// ---- game over ----
void GameplayScene::gameoverRoutine() {
    if (mode == MODE_GAMEOVER) return;
    mode = MODE_GAMEOVER;
    unschedule(schedule_selector(GameplayScene::enemyUpdate));
    for (unsigned i = 0; i < enemies->count(); ++i) ((BasicEnemy*)enemies->objectAtIndex(i))->gameoverFade();
    SimpleAudioEngine::sharedEngine()->playEffect("gameover.ogg");
    if (score > bestScore) { bestScore = score; CCUserDefault::sharedUserDefault()->setIntegerForKey("bestScore", bestScore); }
    saveLifetimeStats();
    ObjCCalls::reportScore(score, "gunstorm");
    runAction(CCSequence::create(CCDelayTime::create(1.3f),
        CCCallFunc::create(this, callfunc_selector(GameplayScene::gameoverStats)), NULL));
}

void GameplayScene::gameoverStats() {
    CCSize w = CCDirector::sharedDirector()->getWinSize();
    CCLayerColor* dim = CCLayerColor::create(ccc4(0, 0, 0, 170));
    addChild(dim, 60);
    float sum = 0; for (size_t i = 0; i < reactions.size(); ++i) sum += reactions[i];
    char avg[32]; snprintf(avg, sizeof(avg), "%.2f secs", reactions.empty() ? 0.0f : sum / reactions.size());
    std::string lines[6] = {
        fmt("TRIAL SCORE: %d", score), fmt("TRIAL REACHED: %d", level), fmt("best - %d", bestScore),
        "RATING: " + calculateReactionGrade(), fmt("KILLS - %d", kills), avg };
    for (int i = 0; i < 6; ++i) {
        CCNode* l = makeText(lines[i], 1.0f, 48.0f);
        if (!l) continue;
        l->setPosition(ccp(w.width * 0.5f, w.height * (0.86f - i * 0.085f)));
        addChild(l, 90);
    }
    btnRetry->setPosition(ccp(w.width * 0.35f, w.height * 0.2f));
    btnQuit->setPosition(ccp(w.width * 0.65f, w.height * 0.2f));
    btnRetry->setActive(true); btnQuit->setActive(true);
}

void GameplayScene::checkGameoverButtons(const CCPoint& p) {
    if (btnRetry->containsPoint(p)) { SimpleAudioEngine::sharedEngine()->playEffect("playPressed.ogg"); triggerRestart(); }
    else if (btnQuit->containsPoint(p)) quitScene();
}

void GameplayScene::rankCheck() { /* original: ObjCCalls::getLoadedRank(); leaderboard removed -> "offline" */ }

// ---- persistence (APPROXIMATED key names) ----
void GameplayScene::loadLifetimeStats() {
    CCUserDefault* u = CCUserDefault::sharedUserDefault();
    bestScore = u->getIntegerForKey("bestScore", 0);
    lifetimeKills = u->getIntegerForKey("lifetimeKills", 0);
    lifetimeDummies = u->getIntegerForKey("lifetimeDummies", 0);
    lifetimePsychics = u->getIntegerForKey("lifetimePsychics", 0);
    lifetimeDoubleShots = u->getIntegerForKey("lifetimeDoubleShots", 0);
}
void GameplayScene::saveLifetimeStats() {
    CCUserDefault* u = CCUserDefault::sharedUserDefault();
    u->setIntegerForKey("lifetimeKills", lifetimeKills);
    u->setIntegerForKey("lifetimeDummies", lifetimeDummies);
    u->setIntegerForKey("lifetimePsychics", lifetimePsychics);
    u->setIntegerForKey("lifetimeDoubleShots", lifetimeDoubleShots);
    u->flush();
}
