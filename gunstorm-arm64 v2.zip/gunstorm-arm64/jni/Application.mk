APP_STL := gnustl_static
APP_ABI := arm64-v8a
APP_PLATFORM := android-21
NDK_TOOLCHAIN_VERSION := clang
APP_CPPFLAGS := -frtti -fexceptions -std=gnu++11 -DCOCOS2D_DEBUG=0 -Wno-deprecated-declarations -Wno-narrowing -Wno-c++11-narrowing
APP_CFLAGS := -fsigned-char
