#include "MissDisplay.h"
using namespace cocos2d;

MissDisplay* MissDisplay::create(CCNode* parent, int maxMisses) {
    MissDisplay* m = new MissDisplay();
    m->maxMisses = maxMisses;
    m->misses = 0;
    m->icons = CCArray::create();
    m->icons->retain();
    m->init();
    m->autorelease();
    m->setup(parent);
    return m;
}

void MissDisplay::setup(CCNode* parent) {
    CCSize win = CCDirector::sharedDirector()->getWinSize();
    parent->addChild(this, 50);
    for (int i = 0; i < maxMisses; ++i) {
        CCSprite* s = CCSprite::createWithSpriteFrameName("miss.png");
        if (!s) continue;
        s->setPosition(ccp(win.width - 70.0f - i * (s->getContentSize().width + 10.0f), win.height - 70.0f));
        s->setOpacity(70);
        addChild(s);
        icons->addObject(s);
    }
}

void MissDisplay::resetMisses() {
    misses = 0;
    for (unsigned i = 0; i < icons->count(); ++i)
        ((CCSprite*)icons->objectAtIndex(i))->setOpacity(70);
}

void MissDisplay::addMiss() {
    if (misses < maxMisses && misses < (int)icons->count())
        ((CCSprite*)icons->objectAtIndex(misses))->setOpacity(255);
    ++misses;
}
