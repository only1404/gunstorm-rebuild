#ifndef __MENUBUTTON_H__
#define __MENUBUTTON_H__
#include "cocos2d.h"
#include <string>

// RECONSTRUCTED (APPROXIMATED). The original looked up "<name>-button.png" and
// "<name>-button_pressed.png" sprite frames, but those frames are NOT present in this APK's
// plists, so this build draws a bitmap-font label (gunstorm.fnt) instead. Original method names:
// create / setActive / displayPressedFrame.
class MenuButton : public cocos2d::CCNode {
public:
    static MenuButton* create(const std::string& name, cocos2d::CCPoint pos, cocos2d::CCNode* parent);
    void setActive(bool active);
    bool isActive() const { return active; }
    void displayPressedFrame(bool pressed);
    bool containsPoint(const cocos2d::CCPoint& worldPoint);
    const std::string& getName() const { return name; }
private:
    std::string name;
    bool active;
    cocos2d::CCLabelBMFont* label;
};
#endif
