package com.dobsoftstudios.gunstorm;

import org.cocos2dx.lib.Cocos2dxActivity;
import org.cocos2dx.lib.Cocos2dxGLSurfaceView;

/** Thin Cocos2d-x 2.1.5 host activity. The original's ad/social SDKs were removed. */
public class GunStormActivity extends Cocos2dxActivity {
    @Override
    public Cocos2dxGLSurfaceView onCreateView() {
        Cocos2dxGLSurfaceView glSurfaceView = new Cocos2dxGLSurfaceView(this);
        glSurfaceView.setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        return glSurfaceView;
    }

    static {
        System.loadLibrary("game");
    }
}
