#include "StartScene.h"
#include "GameplayScene.h"
#include "SimpleAudioEngine.h"
using namespace cocos2d;
using namespace CocosDenshion;

CCScene* StartScene::scene() {
    CCScene* s = CCScene::create();
    s->addChild(StartScene::create());
    return s;
}

bool StartScene::init() {
    if (!CCLayer::init()) return false;
    buttonsReady = false; starting = false;
    setTouchEnabled(true);
    CCSize w = CCDirector::sharedDirector()->getWinSize();

    addChild(CCLayerColor::create(ccc4(20, 14, 10, 255)), -10);

    logo = CCSprite::createWithSpriteFrameName("logo_full.png");
    if (logo) {
        logo->setPosition(ccp(w.width * 0.5f, w.height * 0.68f));
        logo->setOpacity(0);
        addChild(logo, 2);
    }
    playButton = CCSprite::createWithSpriteFrameName("play.png");
    if (playButton) {
        playButton->setPosition(ccp(w.width * 0.5f, w.height * 0.28f));
        playButton->setVisible(false);
        addChild(playButton, 2);
    }
    bool on = CCUserDefault::sharedUserDefault()->getBoolForKey("sfxOn", true);
    volumeButton = CCSprite::createWithSpriteFrameName(on ? "volumeOn.png" : "volumeOff.png");
    if (volumeButton) {
        volumeButton->setPosition(ccp(w.width - 100.0f, 100.0f));
        volumeButton->setVisible(false);
        addChild(volumeButton, 2);
    }
    runAction(CCSequence::create(CCDelayTime::create(0.3f),
        CCCallFunc::create(this, callfunc_selector(StartScene::beginLogo)), NULL));
    return true;
}

void StartScene::beginLogo() {
    SimpleAudioEngine::sharedEngine()->playEffect("intro.ogg");
    if (logo) logo->runAction(CCFadeIn::create(0.8f));
    runAction(CCSequence::create(CCDelayTime::create(1.0f),
        CCCallFunc::create(this, callfunc_selector(StartScene::beginButtons)), NULL));
}

void StartScene::beginButtons() {
    SimpleAudioEngine::sharedEngine()->playEffect("titlev2.ogg");
    if (playButton) playButton->setVisible(true);
    if (volumeButton) volumeButton->setVisible(true);
    buttonsReady = true;
}

void StartScene::toggleSfx() {
    CCUserDefault* u = CCUserDefault::sharedUserDefault();
    bool on = !u->getBoolForKey("sfxOn", true);
    u->setBoolForKey("sfxOn", on);
    u->flush();
    SimpleAudioEngine::sharedEngine()->setEffectsVolume(on ? 1.0f : 0.0f);
    CCSpriteFrame* f = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName(on ? "volumeOn.png" : "volumeOff.png");
    if (f && volumeButton) volumeButton->setDisplayFrame(f);
}

void StartScene::ccTouchesBegan(CCSet* touches, CCEvent*) {
    if (!buttonsReady || starting) return;
    CCTouch* t = (CCTouch*)(*touches->begin());
    CCPoint p = t->getLocation();
    if (volumeButton && volumeButton->boundingBox().containsPoint(p)) { toggleSfx(); return; }
    if (playButton && playButton->boundingBox().containsPoint(p)) {
        CCSpriteFrame* f = CCSpriteFrameCache::sharedSpriteFrameCache()->spriteFrameByName("playPressed.png");
        if (f) playButton->setDisplayFrame(f);
        SimpleAudioEngine::sharedEngine()->playEffect("playPressed.ogg");
        starting = true;
        runAction(CCSequence::create(CCDelayTime::create(0.25f),
            CCCallFunc::create(this, callfunc_selector(StartScene::startGame)), NULL));
    }
}
void StartScene::ccTouchesEnded(CCSet*, CCEvent*) {}

void StartScene::startGame() {
    CCDirector::sharedDirector()->replaceScene(CCTransitionFade::create(0.4f, GameplayScene::scene()));
}
