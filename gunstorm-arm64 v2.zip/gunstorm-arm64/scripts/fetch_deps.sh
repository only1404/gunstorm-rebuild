#!/usr/bin/env bash
# Downloads Cocos2d-x 2.1.5 (MIT) and the third-party libraries that have no arm64 prebuilts in it.
set -euo pipefail
source "$(dirname "$0")/env.sh"
mkdir -p "$TP"; cd "$TP"

if [ ! -d cocos2d-x/cocos2dx ]; then
  echo ">> Cocos2d-x 2.1.5"
  TAG="$(git ls-remote --tags https://github.com/cocos2d/cocos2d-x.git 2>/dev/null \
        | sed 's|.*refs/tags/||; s|\^{}||' | grep -E '(^|[-_])2\.1\.5$' | sort -u | head -1 || true)"
  if [ -n "$TAG" ]; then
    echo "   using git tag: $TAG"
    git clone --depth 1 --branch "$TAG" https://github.com/cocos2d/cocos2d-x.git cocos2d-x
  else
    echo "   no git tag found, trying the official archive"
    curl -fL -o cocos2d-x-2.1.5.zip https://cocos2d-x.org/filedown/cocos2d-x-2.1.5.zip
    unzip -q cocos2d-x-2.1.5.zip && mv cocos2d-x-2.1.5 cocos2d-x
  fi
fi
test -d cocos2d-x/cocos2dx || { echo "ERROR: cocos2d-x/cocos2dx missing after download"; exit 1; }
echo "   license:"; ls cocos2d-x | grep -i licen || true

fetch() { # name url1 [url2]
  local name="$1"; shift
  [ -d "$name" ] && return 0
  for u in "$@"; do
    echo ">> $name <- $u"
    if curl -fL --retry 3 -o "$name.tgz" "$u"; then mkdir "$name.tmp" && tar xzf "$name.tgz" -C "$name.tmp" --strip-components=1 && mv "$name.tmp" "$name" && rm -f "$name.tgz" && return 0; fi
  done
  echo "ERROR: could not download $name"; exit 1
}
# libpng 1.2.46 = the version found inside the original libgame.so (matches the engine's headers)
fetch libpng-1.2.46 \
  https://downloads.sourceforge.net/project/libpng/libpng12/1.2.46/libpng-1.2.46.tar.gz \
  https://github.com/glennrp/libpng/archive/refs/tags/v1.2.46.tar.gz
fetch libjpeg-turbo https://github.com/libjpeg-turbo/libjpeg-turbo/archive/refs/tags/2.1.5.1.tar.gz
fetch libtiff https://download.osgeo.org/libtiff/tiff-4.5.1.tar.gz

echo ">> applying patches"
"$ROOT/scripts/apply_patches.sh"
echo "fetch_deps OK"
