// RECONSTRUCTED from AppDelegate::applicationDidFinishLaunching (ARM32 disassembly).
// Verified in the original: search paths "common","music","sfx" + "hd2"/"hd" per screen size,
// log strings "Screen width is %.2f"/"Using hd2 assets", CCUserDefault first-run init,
// sprite-frame caches for characterassets/enemyassets, preload of the 16 sfx files.
// APPROXIMATED: the exact screen-size -> resource tier/scale table (the original has ~6
// branches with factors 0.5/0.85/0.9/1.1/1.35 and thresholds 1050/1090/1500). Here the art is
// treated as authored for 1920x1080 ("hd") and 3840x2160 ("hd2", exactly 2x the hd files).
#include "AppDelegate.h"
#include "StartScene.h"
#include "GameplayScene.h"
#include "SimpleAudioEngine.h"

using namespace cocos2d;
using namespace CocosDenshion;

AppDelegate::AppDelegate() {}
AppDelegate::~AppDelegate() { SimpleAudioEngine::end(); }

static const char* kSfx[] = {
    "enemy_shoot.ogg", "gameover.ogg", "intro.ogg", "light_off.ogg", "miss.ogg",
    "playPressed.ogg", "shot_1.ogg", "shot_2.ogg", "shot_3.ogg", "shot_headless.ogg",
    "spotlight.ogg", "titlev2.ogg", "yell_1.ogg", "yell_2.ogg", "yell_3.ogg", "yell_4.ogg"
};

bool AppDelegate::applicationDidFinishLaunching() {
    CCDirector* director = CCDirector::sharedDirector();
    CCEGLView* view = CCEGLView::sharedOpenGLView();
    director->setOpenGLView(view);
    director->setDisplayStats(false);
    director->setAnimationInterval(1.0 / 60.0);

    CCSize frame = view->getFrameSize();
    CCLog("Screen width is %.2f", frame.width);
    CCLog("Screen height is %.2f", frame.height);

    // Logical coordinate system: 1080 units high, width follows the screen aspect ratio
    // (S24 Ultra is ~19.5:9, so the playfield is wider than 16:9 and layouts use winSize fractions).
    const float designH = 1080.0f;
    float designW = designH * frame.width / frame.height;
    view->setDesignResolutionSize(designW, designH, kResolutionExactFit);

    bool useHd2 = frame.height >= 1300.0f;   // APPROXIMATED threshold
    std::vector<std::string> paths;
    paths.push_back(useHd2 ? "hd2" : "hd");
    paths.push_back("common");
    paths.push_back("music");
    paths.push_back("sfx");
    paths.push_back("");                      // assets root (fonts/plists duplicated there in the original)
    CCFileUtils::sharedFileUtils()->setSearchPaths(paths);
    director->setContentScaleFactor(useHd2 ? 2.0f : 1.0f);
    CCLog(useHd2 ? "Using hd2 assets" : "Using hd assets");

    // First-run defaults (original: getIntegerForKey + setBoolForKey + 2x setIntegerForKey + flush).
    // Key names are APPROXIMATED (not recoverable from the pooled strings).
    CCUserDefault* ud = CCUserDefault::sharedUserDefault();
    if (ud->getIntegerForKey("launched") == 0) {
        ud->setBoolForKey("sfxOn", true);
        ud->setIntegerForKey("launched", 1);
        ud->setIntegerForKey("bestScore", 0);
        ud->flush();
    }

    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("characterassets.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("enemyassets.plist");
    CCSpriteFrameCache::sharedSpriteFrameCache()->addSpriteFramesWithFile("spineassets.plist");

    for (unsigned i = 0; i < sizeof(kSfx) / sizeof(kSfx[0]); ++i)
        SimpleAudioEngine::sharedEngine()->preloadEffect(kSfx[i]);
    bool sfxOn = ud->getBoolForKey("sfxOn", true);
    SimpleAudioEngine::sharedEngine()->setEffectsVolume(sfxOn ? 1.0f : 0.0f);

    director->runWithScene(StartScene::scene());
    return true;
}

void AppDelegate::applicationDidEnterBackground() {
    if (GameplayScene::current()) GameplayScene::current()->pauseGame();   // original has a background callback
    CCDirector::sharedDirector()->stopAnimation();
    SimpleAudioEngine::sharedEngine()->pauseBackgroundMusic();
}

void AppDelegate::applicationWillEnterForeground() {
    CCDirector::sharedDirector()->startAnimation();
    SimpleAudioEngine::sharedEngine()->resumeBackgroundMusic();
}
