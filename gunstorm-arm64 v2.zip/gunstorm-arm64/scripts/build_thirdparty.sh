#!/usr/bin/env bash
# Builds libjpeg + libtiff for arm64-v8a (CMake 3.10.2 + NDK r17c toolchain) and generates
# ndk-build "override" modules so cocos2dx/Android.mk finds arm64 versions of its prebuilt libs.
set -euo pipefail
source "$(dirname "$0")/env.sh"
OUT="$TP/arm64-prefix"; mkdir -p "$OUT"
TOOLCHAIN="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake"
COMMON=(-G Ninja -DCMAKE_MAKE_PROGRAM="$NINJA_BIN" -DCMAKE_TOOLCHAIN_FILE="$TOOLCHAIN"
        -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-21 -DANDROID_STL=gnustl_static
        -DANDROID_TOOLCHAIN=clang -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX="$OUT"
        -DCMAKE_POSITION_INDEPENDENT_CODE=ON)

if [ ! -f "$OUT/lib/libjpeg.a" ]; then
  echo ">> libjpeg-turbo"
  "$CMAKE_BIN" -S "$TP/libjpeg-turbo" -B "$TP/build-jpeg" "${COMMON[@]}" \
     -DENABLE_SHARED=OFF -DENABLE_STATIC=ON -DWITH_SIMD=OFF -DWITH_TURBOJPEG=OFF
  "$CMAKE_BIN" --build "$TP/build-jpeg" --target install
fi
if [ ! -f "$OUT/lib/libtiff.a" ]; then
  echo ">> libtiff"
  "$CMAKE_BIN" -S "$TP/libtiff" -B "$TP/build-tiff" "${COMMON[@]}" \
     -DBUILD_SHARED_LIBS=OFF -Dtiff-tools=OFF -Dtiff-tests=OFF -Dtiff-contrib=OFF -Dtiff-docs=OFF \
     -Dzlib=OFF -Djpeg=OFF -Djbig=OFF -Dlzma=OFF -Dzstd=OFF -Dwebp=OFF -Dlerc=OFF -Dpixarlog=OFF -Dold-jpeg=OFF
  "$CMAKE_BIN" --build "$TP/build-tiff" --target install
fi

echo ">> generating ndk-build override modules"
PB="$COCOS2DX_ROOT/cocos2dx/platform/third_party/android/prebuilt"
rm -rf "$OVERRIDES"; mkdir -p "$OVERRIDES"
if [ ! -d "$PB" ]; then echo "WARNING: $PB not found - engine layout differs from expectation"; fi
for d in "$PB"/*/; do
  [ -f "$d/Android.mk" ] || continue
  dir="$(basename "$d")"
  mods="$(grep -E '^\s*LOCAL_MODULE\s*:?=' "$d/Android.mk" | sed 's/.*=\s*//' | tr -d ' \r')"
  for mod in $mods; do
    for target in "$OVERRIDES/$dir" "$OVERRIDES/cocos2dx/platform/third_party/android/prebuilt/$dir"; do
      mkdir -p "$target"
      case "$mod" in
        *png*)
          cat > "$target/Android.mk" <<EOM
LOCAL_PATH := \$(call my-dir)
include \$(CLEAR_VARS)
LOCAL_MODULE := $mod
LOCAL_SRC_FILES := \$(addprefix $TP/libpng-1.2.46/,png.c pngerror.c pngget.c pngmem.c pngpread.c pngread.c pngrio.c pngrtran.c pngrutil.c pngset.c pngtrans.c pngwio.c pngwrite.c pngwtran.c pngwutil.c)
LOCAL_C_INCLUDES := $TP/libpng-1.2.46
LOCAL_EXPORT_C_INCLUDES := $TP/libpng-1.2.46
LOCAL_EXPORT_LDLIBS := -lz
include \$(BUILD_STATIC_LIBRARY)
EOM
          ;;
        *jpeg*|*jpg*)
          cat > "$target/Android.mk" <<EOM
LOCAL_PATH := \$(call my-dir)
include \$(CLEAR_VARS)
LOCAL_MODULE := $mod
LOCAL_SRC_FILES := $OUT/lib/libjpeg.a
LOCAL_EXPORT_C_INCLUDES := $OUT/include
include \$(PREBUILT_STATIC_LIBRARY)
EOM
          ;;
        *tiff*)
          cat > "$target/Android.mk" <<EOM
LOCAL_PATH := \$(call my-dir)
include \$(CLEAR_VARS)
LOCAL_MODULE := $mod
LOCAL_SRC_FILES := $OUT/lib/libtiff.a
LOCAL_EXPORT_C_INCLUDES := $OUT/include
include \$(PREBUILT_STATIC_LIBRARY)
EOM
          ;;
        *)
          # Not needed by the game (curl, xml2, ...): empty module so linking resolves if unused.
          echo 'int gunstorm_empty_'"$mod"'_stub(void){return 0;}' | tr -c 'A-Za-z0-9_(){};\n ' '_' > "$target/empty.c"
          cat > "$target/Android.mk" <<EOM
LOCAL_PATH := \$(call my-dir)
include \$(CLEAR_VARS)
LOCAL_MODULE := $mod
LOCAL_SRC_FILES := empty.c
include \$(BUILD_STATIC_LIBRARY)
EOM
          ;;
      esac
    done
    echo "   override: $mod ($dir)"
  done
done
echo "build_thirdparty OK"
