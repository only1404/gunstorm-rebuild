#ifndef __PLAYERCHARACTER_H__
#define __PLAYERCHARACTER_H__
#include "cocos2d.h"
#include <string>

// PlayerCharacter: RECONSTRUCTED.
// VERIFIED: frame naming Avatar<combo>-{Blank,Fire,Recoil}.png for the 21 combos
// A,AB,AC,AD,AE,AF,B,BC,BD,BE,BF,C,CD,CE,CF,D,DE,DF,E,EF,F (six target spots, optional second
// target = "double shot"), AvatarReset.png, AvatarDishonor.png, Avatar-Death00..06.png,
// shotfromright.plist muzzle particle, method names from the symbol table.
// APPROXIMATED: timings of every animation, sprite position, particle placement.
class PlayerCharacter : public cocos2d::CCSprite {
public:
    static PlayerCharacter* create();
    void initiate(cocos2d::CCNode* parent);
    void setupAnimations();
    void addAnimationWithString(const std::string& combo);
    void addDeathAnimation();
    void resetPoses();

    // id: index into the 21-combo table; use comboIndex() to build it from spot indexes (0..5)
    static int comboIndex(int spotA, int spotB /* -1 if single */);
    void playAnimation(int id);
    void playResetPose();
    void playResetPoseWithDelay(float delay);
    void playDishonorPose();
    void playDishonorPoseWithDelay(float delay);
    void playDeathAnimationWithFlip(bool flip);
    void fadePreviousSprite() {}
    void shuffleSprites() {}
    void synchDisplayFrame() {}
private:
    cocos2d::CCParticleSystemQuad* muzzle;
    cocos2d::CCArray* animations;   // CCAnimation* per combo
    cocos2d::CCAnimation* deathAnim;
};
#endif
