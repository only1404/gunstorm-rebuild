#ifndef __STARTSCENE_H__
#define __STARTSCENE_H__
#include "cocos2d.h"

// StartScene: RECONSTRUCTED (APPROXIMATED visuals).
// VERIFIED: sounds intro.ogg (logo), titlev2.ogg (buttons), playPressed.ogg on Play, "sfxOn" key and
// volumeOn/volumeOff frames for the sound toggle, touch handling via ccTouchesBegan, frames
// logo_full / play / playPressed / leaderboard / medals exist in spineassets.plist.
// NOT done: the Spine animations (logo.json, playButton.json, ...) -> static frames are used instead
// (the original drives them with the spine-c runtime). Facebook/Twitter/Leaderboard buttons removed.
class StartScene : public cocos2d::CCLayer {
public:
    static cocos2d::CCScene* scene();
    CREATE_FUNC(StartScene);
    virtual bool init();
    void beginLogo();
    void beginButtons();
    void toggleSfx();
    virtual void ccTouchesBegan(cocos2d::CCSet* touches, cocos2d::CCEvent* event);
    virtual void ccTouchesEnded(cocos2d::CCSet* touches, cocos2d::CCEvent* event);
    void startGame();
private:
    cocos2d::CCSprite* playButton;
    cocos2d::CCSprite* volumeButton;
    cocos2d::CCSprite* logo;
    bool buttonsReady;
    bool starting;
};
#endif
